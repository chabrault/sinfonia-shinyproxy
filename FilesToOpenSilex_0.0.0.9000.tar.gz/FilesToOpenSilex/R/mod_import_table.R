#' import_table UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
mod_import_table_ui <- function(id){
  ns <- NS(id)
  tagList(
    # Try with different Bootstrap version
    # theme = bslib::bs_theme(version = 4),
    fluidRow(
      column(
        width = 2,

        shinyWidgets::actionBttn(ns("launch_modal"),
                                 "Lancer importation", color="warning",
                                 size="md", style="fill")
      ),
      column(
        width = 10,
        #tags$b("Données importées :"),
        verbatimTextOutput(outputId = ns("name")),
        #verbatimTextOutput(outputId = ns("data"))
        #DT::dataTableOutput(ns("data"))
        reactable::reactableOutput(ns("data"))
      )
    )

  )
}

#' import_table Server Functions
#'
#' @noRd
#' @importFrom datamods import_ui import_modal import_server import_file_ui
mod_import_table_server <- function(id){
  moduleServer( id, function(input, output, session){
    ns <- session$ns
    observeEvent(input$launch_modal, {
      # req(input$from)
      datamods::import_modal(
        id = ns("import_modal"),
        from = c("file","copypaste"),
        size="xl",
        title = "Importation des données"
      )
    })
    imported <- datamods::import_server("import_modal",
                                        allowed_status="OK",
                                        return_class = "data.frame",
                                        read_fns = list(
                                          xlsx = function(file, sheet, skip) {
                                            readxl::read_excel(path = file, sheet = sheet, skip = skip, na = c("DM"))
                                          },
                                          xls = function(file, sheet, skip) {
                                            readxl::read_excel(path = file, sheet = sheet, skip = skip, na = c("DM"))
                                          }
                                        )
    )

    # # change "DM" to NA for character columns
    dat <- reactive({
      req(imported$data())
      #   dat <- imported$data()
      #   charCols <- names(which(sapply(dat, class) == "character"))
      #   #print(charCols)
      #   dat[,charCols] <- apply(dat[,charCols],c(2), stringr::str_replace_all, "DM",NA_character_)
      #   return(dat)
    })

    #print(isolate(class(dat)))


    output$name <- renderPrint({
      req(imported$name())
      imported$name()
    })
    # output$data <- renderPrint({
    #   req(imported$data())
    #   imported$data()
    # })

    # output$data <- DT::renderDataTable({
    #   #req(imported$data())
    #   #imported$data()
    #   req(dat())
    #   dat()
    #
    # })


    output$data <- reactable::renderReactable(
      reactable::reactable( req(dat()),
                            rownames=FALSE,
                            sortable=TRUE,
                            filterable=TRUE,
                            striped=TRUE,
                            resizable=TRUE,
                            pagination=FALSE,
                            searchable=TRUE,
                            highlight=TRUE,
                            bordered=TRUE,
                            defaultColDef=reactable::colDef(align = "center",  filterable = TRUE),
                            height=900,fullWidth = TRUE
      )
    )

    #return(reactive(imported$data()))
    return(reactive(dat()))

  })
}

## To be copied in the UI
# mod_import_table_ui("import_table_1")

## To be copied in the server
# mod_import_table_server("import_table_1")
