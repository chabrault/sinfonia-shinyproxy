#' update_geno UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
mod_update_geno_ui <- function(id){
  ns <- NS(id)
  tagList(
    shiny::verbatimTextOutput(ns("maj_geno")),
    downloadButton(ns("DWNLD_GEN_UP"),"Télécharger le fichier"),
    br()

  )
}

#' update_geno Server Functions
#'
#' @noRd
mod_update_geno_server <- function(id, host, user, password, data_r6){
  moduleServer( id, function(input, output, session){
    ns <- session$ns
    ## get_token function in utils_helpers.R
    token <- get_token(host=host, user=user,password=password)

    startTime <- Sys.time()

    ## the POST service core/germplasm/export does not exist for Sinfonia because of OpenSilex version
    if(data_r6$ref_file$prefix_SO_URI[data_r6$ref_file$Name == "Id2"] != "Sinfonia"){
      # GEN = httr::GET(paste0(host,"/core/germplasm"),
      #                 query = list(page_size = 10000),#,page=1),
      #                 httr::content_type_json(),encode ="raw",
      #                 config=httr::add_headers(Authorization=token))
      # ##dim(dfGEN)
      # dfGEN = jsonlite::fromJSON(rawToChar(GEN$content))$result
      # # dfGEN
      # dfGEN <- jsonlite::flatten(as.data.frame(dfGEN))
      # dfGEN<- tidyr::unnest(dfGEN, colnames(dfGEN)[sapply(dfGEN, class)=="list"],
      #                       keep_empty = TRUE)
      # # GEN = httr::POST(url=paste0(host,"/core/germplasm/export"),
      # #                  body='{"pageSize":10000}',
      # #                  httr::content_type_json(), encode="json",
      # #                  config=httr::add_headers(Authorization=token))
      # #  dfGEN <- httr::content(GEN,"text/csv", as="parsed",show_col_types = FALSE)
      #
      # # write.table(dfGEN,"fto_files-master/fto_files/VitisExplorer/germplasm.tsv",
      # #             sep="\t",row.names=FALSE, fileEncoding = "UTF-8")
      dfGEN <- get_all_genos_details(host=host,user=user,password=password)

      ## Local download for user
      output$DWNLD_GEN_UP <- downloadHandler(
        filename = "germplasm.csv",content = function(fname){
          write.table(dfGEN,fname, row.names=FALSE, fileEncoding="UTF-8", sep=",")
        }
      )

      executionTime <- Sys.time()-startTime
      #write(paste(Sys.time(),round(executionTime,0),sep=";"),file="sinfoniaFiles/logOS.txt",append=TRUE)
      output$maj_geno <-  shiny::renderPrint({
        cat(paste0("Requête terminée en ",round(executionTime,0)," secondes"))
      })
    }


  })
}

## To be copied in the UI
# mod_update_geno_ui("update_geno_1")

## To be copied in the server
# mod_update_geno_server("update_geno_1")
