#' update_so UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
mod_update_so_ui <- function(id){
  ns <- NS(id)
  tagList(
    shiny::verbatimTextOutput(ns("maj_os")),
    downloadButton(ns("DWNLD_SO_UP"),"Télécharger le fichier"),

    br()
  )
}

#' update_so Server Functions
#'
#' @noRd
mod_update_so_server <- function(id, host, user, password, data_r6){
  moduleServer( id, function(input, output, session){
    ns <- session$ns
    print("update scientific object list")
    #print(token)
    token <- get_token(host=host, user=user,password=password)

    ## first extract the list of experiment
    ## second extract all OS related to each experiment
    #### download the list of variables
    startTime <- Sys.time()
    # 1. GET all experiments
    XP <- httr::GET(paste0(host,"/core/experiments"),
                    query = list(page_size = 10000),
                    httr::content_type_json(),encode ="raw",
                    httr::add_headers(Authorization= token))
    dfXP = jsonlite::fromJSON(rawToChar(XP$content))$result
    # 2. GET all scientific objects for each experiment and store in a data frame
    OSfinal <- data.frame()
    for (i in 1:nrow(dfXP)){
      OSXP = httr::GET(paste0(host,"/core/scientific_objects"),
                       query = list(page_size = 10000,
                                    experiment = paste(dfXP$uri[i])),
                       httr::content_type_json(),encode ="form",
                       httr::add_headers(Authorization= token))
      dfOSXP = jsonlite::fromJSON(rawToChar(OSXP$content))$result
      OSfinal <- rbind(OSfinal,cbind(dfXP[i,c("uri","name")],dfOSXP))
    }
    colnames(OSfinal)[1:2] <- c("uri_expe","name_expe")

    ## Local download for user
    output$DWNLD_SO_UP <- downloadHandler(
      filename = "SO_all_expes.tsv",content = function(fname){
        write.table(OSfinal,fname, row.names=FALSE, fileEncoding="UTF-8", sep="\t")
      }
    )

    executionTime <- Sys.time()-startTime
    #write(paste(Sys.time(),round(executionTime,0),sep=";"),file="sinfoniaFiles/logOS.txt",append=TRUE)
    output$maj_os <-  shiny::renderPrint({
      cat(paste0("Requête terminée en ",round(executionTime,0)," secondes"))
    })

  })
}

## To be copied in the UI
# mod_update_so_ui("update_so_1")

## To be copied in the server
# mod_update_so_server("update_so_1")
