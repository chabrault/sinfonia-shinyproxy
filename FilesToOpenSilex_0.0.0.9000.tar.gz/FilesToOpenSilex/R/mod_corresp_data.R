#' corresp_data UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
mod_corresp_data_ui <- function(id){
  ns <- NS(id)
  tagList(
    fluidRow(
      bs4Dash::box(width=4,
                   # height="150px",
                   title="Choix expérimentation",
                   uiOutput(ns("selExpe_ui")),
                   status="danger",
                   solidHeader = TRUE

      ),
      bs4Dash::box(width=4,
                   # height="150px",
                   title="Choix type objet scientifique",
                   uiOutput(ns("selSOtype_ui")),
                   status="danger",
                   solidHeader = TRUE

      ),
      bs4Dash::box(width=4,
                   # height="150px",
                   title="Choix groupe variable (optionnel)",
                   selectizeInput(ns("grpVar"),"Groupe de variables :",
                                  choices="",selected=NULL,
                                  multiple=TRUE),
                   status="primary"

      )
    ),
    fluidRow(
      bs4Dash::box(width=8,
                   #height="1000px",
                   title="Tableau correspondance",
                   closable = FALSE,
                   maximizable = TRUE,
                   status="danger",
                   style = "overflow-y: scroll",
                   fluidPage(
                     h5("Correspondance entre les colonnes du tableau et les noms de variable"),
                     br(),
                     column(8,
                            ## conditionalPanel doesn't work because of early end of observeEvent, because of dependencies to other modules
                            conditionalPanel("input.selExpe!='' ",#&& input.selSOtype != ''",
                                             rhandsontable::rHandsontableOutput(ns("edit_rht_dat1")), width="100%"),
                     ),
                     # rhandsontable::rHandsontableOutput(ns("edit_rht_dat1")),
                     br(),
                     column(8,
                            shinyWidgets::actionBttn(ns("validCorresp"),
                                                     "Valider", color="warning",
                                                     style="fill",size="lg"),
                            shinyWidgets::downloadBttn(ns("DWNLD_DAT1"),
                                                       "Télécharger fichier",
                                                       color="primary")
                     )
                   )
      ),
      bs4Dash::box(width=4,
                   #height="900px",
                   title=" Aide remplissage",
                   #closable = TRUE,
                   maximizable = TRUE,
                   collapsed=FALSE,
                   status="info",
                   style = "overflow-y: scroll",
                   icon=icon("question"),

                   p("Remplir la colonne ",
                     em("'Correspondance'"),
                     "Avec les noms de variables (voir liste déroulante)"),
                   p("Le remplissage du nom est obligatoire, il se fait dans la colonne ", em("Expression")),
                   p("Si nécessaire, utiliser une formule pour générer le nom comme ",
                     code('paste0("prefix_",PU)'),
                     " si la colonne PU permet d'identifier uniquement l'objet scientifique"),

                   br(),
                   h5("Noms avec accent ou espace"),
                   p("S'il y a des accents dans les noms, il faut les entourer avec un guillemet spécial"),
                   p("Vous pouvez l'obtenir en tapant ", code("AltGr + 7 + Espace")),

                   br(),
                   p("La colonne ",em("Affichage")," permet de sélectionner des colonnes supplémentaires à visualiser"),

                   br(),
                   p("Pour ajouter des variables issues d'un calcul (ratio ou changement d'unité par exemple),",
                     "vous devez ajouter des lignes au tableau.",
                     "Pour cela, se placer sur la dernière ligne du tableau, faire ",code("Clic droit + Insert row below.")),
                   p("Sélectionner la variable dans la colonne ",em("Correspondance"), "et remplir la formule dans la colonne",
                     em("Expression"))

      )
    ),

    br(),
    bs4Dash::box(width=12,
                 height="500px",
                 title="Description des variables sélectionnées",
                 status="pink",
                 DT::dataTableOutput(ns("dfVar")),
                 style = "height:450px; width:100%; overflow-y: scroll;overflow-x: scroll;"
    )
  )


}

#' corresp_data Server Functions
#' @importFrom stats complete.cases na.omit
#' @importFrom utils read.csv read.table write.csv write.table
#'
#' @noRd
mod_corresp_data_server <- function(id, inputDFvar, data_r6){
  moduleServer( id, function(input, output, session){
    ns <- session$ns

    ### MODULE 4: edit data correspondence
    datSO <- data_r6$datSO_all

    ## Select experimentation
    output$selExpe_ui <- renderUI({
      shinyWidgets::radioGroupButtons(ns("selExpe"),
                                      label="Expérimentation",
                                      choices=unique(datSO$name_expe),
                                      selected="",
                                      individual=TRUE,
                                      status = "danger",
                                      checkIcon = list(
                                        yes = icon("ok",
                                                   lib = "glyphicon")))
    })


    ## Select type of scientific object
    output$selSOtype_ui <- renderUI({
      shinyWidgets::radioGroupButtons(ns("selSOtype"),
                                      label="Type objet scientifique",
                                      choices=unique(datSO$rdf_type_name),
                                      selected="",
                                      individual=TRUE,
                                      status = "danger",
                                      checkIcon = list(
                                        yes = icon("ok",
                                                   lib = "glyphicon")))
    })

    ### Scientific object table from a specific experiment
    observeEvent(c(input$selExpe,input$selSOtype),{
      # print(paste0("sel expe: ",input$selExpe))
      # print(paste0("sel so type: ",input$selSOtype))

      ## select rows based on experiment and type of scientific object
      data_r6$datSO <- reactive({
        datSO <- datSO[datSO$name_expe %in% input$selExpe &
                         datSO$rdf_type_name %in% input$selSOtype,]
        return(datSO)
      })


    },ignoreInit = FALSE)# observeEvent selExpe & selSOtype
    # observe(print(datSO()))


    ### Define variables
    variables <- isolate(inputDFvar$variables)

    #if(input$switch == "Charger fichier"){
    # User edit correspondance between column names and variable names
    updateSelectizeInput(session, inputId = "grpVar",
                         choices=unique(variables$group),
                         selected=unique(variables$group))
    #}




    ## create the data frame to be edited for correspondence
    tmp_edit <- reactive({
      # observeEvent(input$file1,{
      #   inFile <- input$file1
      #   print(inFile)
      #   if (is.null(inFile)){
      #     print("null")
      df <- data.frame(Variable=c(colnames(req(data_r6$import())),"",""),
                       Correspondance=c(rep(NA,ncol(req(data_r6$import()))),"Nom","Date"),
                       Expression="",
                       Affichage=FALSE)

      ## if correspondence with variable name => add in correspondance column
      var_com <- intersect(df$Variable,variables$name)
      idx <- which(df$Variable %in% var_com,arr.ind=TRUE)
      df$Correspondance[idx] <- df$Variable[idx]
      ## if correspondence with alternative name
      var_com_alt <- intersect(df$Variable,variables$alternative_name)
      idx <- which(df$Variable %in% var_com_alt,arr.ind=TRUE)
      df$Correspondance[idx] <- variables$name[match(df$Variable[idx],variables$alternative_name)]
      ## if correspondence with table corresp_variable_name.csv
      var_com_df <- intersect(df$Variable,inputDFvar$corresp_var$var_used)
      idx <- which(df$Variable %in% var_com_df,arr.ind=TRUE)
      df$Correspondance[idx] <- inputDFvar$corresp_var$var_OpenSilex[match(df$Variable[idx],inputDFvar$corresp_var$var_used)]

      #   } else {
      #     print("else")
      #     df <- read.csv(inFile$datapath, header = TRUE)
      #     print(df$Variable)
      #   }
      # },ignoreInit = FALSE)

      return(df)
    })

    idxNomDate <- reactive({
      which(tmp_edit()$Correspondance %in% c("Nom","Date"), arr.ind=TRUE)
    })
    ## create rhandsontable object to define edition
    output$edit_rht_dat1 <- rhandsontable::renderRHandsontable(
      rhandsontable::rhandsontable(tmp_edit(), width = 1000) %>%
        rhandsontable::hot_rows(rowHeights = 30) %>%
        ## set nom / date cells as read only
        rhandsontable::hot_cell(row=idxNomDate()[1], col="Correspondance", readOnly=TRUE) %>%
        rhandsontable::hot_cell(row=idxNomDate()[2], col="Correspondance", readOnly=TRUE) %>%

        ## surrounding nom/date with expression
        rhandsontable::hot_table(customBorders = list(list(
          range = list(from = list(row=idxNomDate()[1]-1,col=1),
                       to = list(row=idxNomDate()[2]-1,col=2)),
          top = list(width = 2, color = "red"),
          left = list(width = 2, color = "red"),
          bottom = list(width = 2, color = "red"),
          right = list(width = 2, color = "red")))) %>%

        rhandsontable::hot_table(highlightCol=TRUE,highlightRow=TRUE,rowHeaderWidth=0) %>%
        rhandsontable::hot_col(col="Variable",readOnly=TRUE) %>%
        rhandsontable::hot_col(col="Correspondance",type="dropdown",
                               source=c("",sort(variables$name[variables$group %in% c(input$grpVar,NA)])),
                               allowInvalid=FALSE) %>%
        rhandsontable::hot_col(col="Expression",type="dropdown",
                               source=c("",
                                        "as.numeric(format(as.Date(COLONNE),format='%j'))",
                                        "paste0('B',bloc,'R',Rang)",
                                        "paste0('SOtest_PU_',PU)",
                                        "paste0('Test_INRAE_ResDur_',PU)",
                                        "paste0('B',bloc,'R',Rang,'s',`Première souche`)",
                                        'paste0(paste0(substr(`Cépage`,1,1),"-",substring(`Cépage`,2)),"_",Modalite)'),
                               allowInvalid=TRUE) %>%
        rhandsontable::hot_cols(halign="htCenter",valign="htMiddle",
                                manualColumnResize=TRUE,colWidths=c(200,300,300,80)))



    ## Local download for user
    output$DWNLD_DAT1 <- downloadHandler(
      filename = paste0("corresp_DAT1",format(Sys.time(),"%Y-%m-%d_%H%M"),".csv"),
      content = function(fname){
        write.csv(req(rhandsontable::hot_to_r(input$edit_rht_dat1)),
                  fname, row.names=FALSE, fileEncoding="UTF-8")}
    )

    ## print table of selected variables, automatically synchronised to see variable details
    printDfVar <- reactive({
      df <- rhandsontable::hot_to_r(input$edit_rht_dat1)
      varsSel <- c(df$Correspondance[df$Correspondance %in% variables$name],
                   df$Expression[df$Expression %in% variables$name])
      return(variables[variables$name %in% varsSel,])
    })
    output$dfVar <- DT::renderDataTable(
      printDfVar(),
      options=list(scroller=TRUE, scrollX=TRUE),
      width = "100%")

    ## group information related to scientific object in one data frame: covarDFSO
    covarDFSO <- reactiveVal(NULL)
    moreCols <- reactiveVal(NULL)

    observeEvent(c(input$validCorresp),{
      mc <- character(0)
      mc <- hot_to_r(input$edit_rht_dat1)$Variable[hot_to_r(input$edit_rht_dat1)$Affichage]
      if(length(mc) == 0){
        mc <- NA
      } else {mc = na.omit(mc)}
      #print(paste0("mc:",mc))
      if(all(is.na(mc))){
        moreCols("noMoreCols")
      } else {moreCols(mc)}
      covarDFSO(
        create_data_corresp(corresp_data=req(hot_to_r(input$edit_rht_dat1)),
                            data=req(data_r6$import()),
                            datSO=req(data_r6$datSO()),
                            variables=variables,
                            moreCols=mc,
                            data_r6=data_r6)
      )
      #print("ncol covarDFSO module:",ncol(isolate(req(covarDFSO()))))


    },ignoreInit = TRUE,ignoreNULL = TRUE)


    # highlight rows where URI is not corresponding
    df_colRender <- reactive({
      df_colRen <- data.frame()
      #observe(print(covarDFSO()$uri))
      #covarDFSO <- isolate(reactive(req(data_r6$covarDFSO())))
      if(any(is.na(covarDFSO()$uri))){
        tmp <- data.frame(row=which(is.na(covarDFSO()$uri), arr.ind=TRUE),
                          col=1,color="orangered")
        df_colRen <- rbind(tmp,verifDatBounds(dat=covarDFSO(),valDF = inputDFvar$ValFile))
      } else{
        df_colRen <- verifDatBounds(dat=covarDFSO(),valDF=inputDFvar$ValFile)
      }
      return(df_colRen)
    })



    #observe(print(paste("moreCols mod",moreCols())))
    return(list(df_colRender=reactive(req(df_colRender())),
                selExpe=reactive(req(input$selExpe)),
                covarDFSO=reactive(req(covarDFSO())),
                datSO=reactive(req(data_r6$datSO())),
                moreCols=reactive(req(moreCols()))
    )
    )
    ## },ignoreInit = TRUE) # observeEvent selExpe & selSOtype
  })
}

## To be copied in the UI
# mod_corresp_data_ui("corresp_data_1")

## To be copied in the server
# mod_corresp_data_server("corresp_data_1")
