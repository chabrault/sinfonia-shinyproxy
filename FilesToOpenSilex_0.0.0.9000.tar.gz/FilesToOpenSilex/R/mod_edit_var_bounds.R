#' edit_var_bounds UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
mod_edit_var_bounds_ui <- function(id){
  ns <- NS(id)
  tagList(
    column(width=4,selectInput(ns("varCols"),"Colonnes à afficher",
                               choices=c(),multiple=TRUE)),
    column(width=4,textInput(ns("searchField"), "Recherche de texte")),
    ##actionButton(ns("saveValidationVar"),"Mise à jour des limites"),
    downloadButton(ns("downloadValidation"),"Télécharger le fichier"),
    rhandsontable::rHandsontableOutput(ns("tabVar"))

  )
}

#' edit_var_bounds Server Functions
#'
#' @noRd
mod_edit_var_bounds_server <- function(id, inputDFvar,data_r6){
  moduleServer( id, function(input, output, session){
    ns <- session$ns
    colsValBound <- c("minValue","maxValue","lwrBound","uprBound")
    if(!all(colsValBound %in% colnames(inputDFvar$variables))){
      inputDFvar$variables <- merge(inputDFvar$variables,
                                    inputDFvar$ValFile,
                                    all.x = TRUE, by=c("uri","name"))
    }
      observe({
        updateVarSelectInput(session,"varCols",
                             data = req(inputDFvar$variables),
                             selected=c("name",colsValBound))
      })

      output$tabVar <- rhandsontable::renderRHandsontable({
        rhot_DFvariables <- rhandsontable::rhandsontable(
          req(inputDFvar$variables)[F_searchText(input$searchField,
                                                 where2findDF = req(inputDFvar$variables),
                                                 cols2find=NULL),
                                    c("uri",req(input$varCols))], #c("uri","name",input$varCols)

          manualColumnResize = TRUE, highlightCol = TRUE, highlightRow = TRUE) %>%
          rhandsontable::hot_table(highlightCol = TRUE, highlightRow = TRUE)
        return(rhot_DFvariables)
      })

      observeEvent(input$saveValidationVar, {
        # convert the handsontable data to a R dataframe
        tempDF <- rhandsontable::hot_to_r(input$tabVar)
        selectedUri <- inputDFvar$variables$uri %in% tempDF$uri  ## select rows as view in user ui

        # copy new values to DFvalidationVar
        inputDFvar$variables[selectedUri,colsValBound] <- tempDF[,colsValBound]

      },ignoreInit = TRUE)

      ## Local download for user
      output$downloadValidation <- downloadHandler(
        filename = paste0("validationVariables",format(Sys.time(),"%Y-%m-%d_%H%M"),".csv"),
        content = function(fname){
          write.csv(req(inputDFvar$ValFile),fname, row.names=FALSE, fileEncoding = "UTF-8")}
      )
  })
}

## To be copied in the UI
# mod_edit_var_bounds_ui("edit_var_bounds_1")

## To be copied in the server
# mod_edit_var_bounds_server("edit_var_bounds_1")
