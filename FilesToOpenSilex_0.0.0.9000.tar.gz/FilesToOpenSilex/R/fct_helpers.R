#' helpers



#' Edit data frame of correspondence for scientific objects properties
#'
#' @param userDF initial data frame of the user
#' @param metaNames names of metadata, depending on scientific object type (character vector)
#' @param corresp table of edited correspondence
#' @param germplasm table of germplasm names and uris
#' @import ggthemes

editDFCorresp <- function(userDF, metaNames, corresp, germplasm){

  # create empty data frame with metadata properties as column
  toEditDF <- data.frame(matrix(ncol = length(metaNames),
                                nrow = nrow(userDF)))
  colnames(toEditDF) <- metaNames
  toEditDF[,corresp$Propriete[!corresp$Edition]] <- NULL
  corresp$Correspondance[is.na(corresp$Correspondance)] <- ""

  # replace NA values by values in userDF for each direct correspondence
  for (i in 1:nrow(corresp)){
    if(!corresp$Correspondance[i] == "" &
       corresp$Correspondance[i] %in% colnames(userDF)){
      toEditDF[[corresp$Propriete[i]]] <- userDF[[corresp$Correspondance[i]]]
    }
  }


  ## Handle columns to be edited by hand after
  corresp$Edition[is.na(corresp$Edition)] <- FALSE
  ## if something is in col correspondance, this column have to be in EditDF
  corresp$Edition[corresp$Correspondance != ""] <- TRUE
  emptyToEditDF <- data.frame(matrix(ncol = sum(corresp$Edition),
                                     nrow = nrow(userDF)))
  colnames(emptyToEditDF) <- corresp$Propriete[corresp$Edition]
  ## EDITED
  emptyToEditDF <- emptyToEditDF[,setdiff(colnames(emptyToEditDF),colnames(toEditDF))]
  toEditDF <- cbind(emptyToEditDF,toEditDF)

  # replace NA values by values in userDF for each correspondence defined with a formula
  for (i in 1:nrow(corresp)){
    if(!corresp$Correspondance[i] == "" &
       !corresp$Correspondance[i] %in% colnames(userDF)){
      txt <- as.character(corresp$Correspondance[i])
      # toEditDF[[corresp$Propriete[i]]] <- userDF[[corresp$Correspondance[i]]]
      toEditDF[[corresp$Propriete[i]]] <- eval(parse(text=txt),envir=userDF)
    }
  }

  df_colRender <- list(df1=data.frame(row=0,col=0,color="green"))
  # palette yellow-red => mapping quality for germplasm + green for perfect mapping
  pal <- c(paletteer::paletteer_c("ggthemes::Red-Gold",n=100,direction=-1),"#BCCFB4FF")
  ## add transparency to the color
  pal <- grDevices::adjustcolor(pal, alpha.f=0.7)
  ### adding germplasm name
  ### guess germplasm from a column
  if("Greffon" %in% corresp$Propriete){
    if(corresp$Correspondance[corresp$Propriete == "Greffon"] != "") {

      vec <- userDF[[corresp[corresp$Propriete == "Greffon","Correspondance"]]]

      ## TODO: extract score of matching for printing color
      toEditDF$Greffon <- as.character(germplasm$name[stringdist::amatch(
        x=tolower(gsub("[[:punct:]]", "",x=vec)),
        table=tolower(gsub("[[:punct:]]", "", germplasm$name)),
        maxDist = 2, q=2, method = "cosine")])
      toEditDF$Greffon_initial <- vec
      ## color column Greffon depending on mapping quality
      dist <- stringdist::stringsim(toEditDF$Greffon, vec)

      df_colRender$df2 <- data.frame(row=seq(length(vec)),
                                     col=NA,
                                     color=as.character(pal[round(dist*100,0)+1]))

      ## set together initial and edited germplasm names
      toEditDF <- dplyr::relocate(toEditDF,Greffon_initial, .before=Greffon)
      df_colRender$df2$col <- which(colnames(toEditDF) == "Greffon", arr.ind=TRUE)
    } else {
      ## needed for rhandsontable
      toEditDF$Greffon <- ""
    }
  }

  ## same thing with PorteGreffe
  if("PorteGreffe" %in% corresp$Propriete){
    if(corresp$Correspondance[corresp$Propriete == "PorteGreffe"] != "") {
      vec <- userDF[[corresp[corresp$Propriete == "PorteGreffe","Correspondance"]]]

      toEditDF$PorteGreffe <- as.character(germplasm$name[stringdist::amatch(
        x=tolower(gsub("[[:punct:]]", "",x=vec)),
        table=tolower(gsub("[[:punct:]]", "", germplasm$name)),
        maxDist = 2, q=2, method = "cosine")])
      toEditDF$PorteGreffe_initial <- vec
      ## color column Greffon depending on mapping quality
      dist <- stringdist::stringsim(toEditDF$PorteGreffe, vec)

      df_colRender$df3 <- data.frame(row=seq(length(vec)),
                                     col=NA,
                                     color=as.character(pal[round(dist*100,0)+1]))

      toEditDF <- dplyr::relocate(toEditDF,PorteGreffe_initial, .before=PorteGreffe)
      df_colRender$df3$col <- which(colnames(toEditDF) == "PorteGreffe", arr.ind=TRUE)
    } else {
      toEditDF$PorteGreffe <- ""
    }
  }
  # transform date column to character for rhandsontable printing (bug)
  if(corresp[corresp$Propriete == "DateCreation","Correspondance"] != ""){
    toEditDF$DateCreation <- as.character(toEditDF$DateCreation)
  }
  if(corresp[corresp$Propriete == "DateDestruction","Correspondance"] != ""){
    toEditDF$DateDestruction <- as.character(toEditDF$DateDestruction)
  }

  #print(str(toEditDF))
  df_colRender <- do.call(rbind, df_colRender)
  #print(head(df_colRender))
  return(list(df=toEditDF,
              colRender=df_colRender))
              #colRender=colRender(df_colRender)))
}




#' Convert to OpenSilex
#' This function takes as input a data frame with defined column associated with scientific object Propriete
#' it changes column names and column type (change to uri, to date format) to correspond to OpenSilex standards
#'
#' @param dat data frame edited with rhandsontable, outputed in mod_corresp_SO
#' @param metadataSO table of metadata properties
#' @param SOtype type of scientific object, one of Plot, MustObject, Sample, Wine
#' @param germplasm table with germplasm name and uri
#' @param data_r6 an R6 object containing in ref_file all information specific to the OpenSilex instance
#' example
# dat <- read.csv(file="outputFiles/corresp_OS/correspOS2_2022-11-03_1505.csv")
#
# prefix=""
# metadataSO <- read.csv(file="Referentiels/metadataVitisExplorer.csv", #metadataSinfonia.csv
#                        header=TRUE,
#                        sep=",",check.names = FALSE,fileEncoding = "UTF-8")
#
# SOtype <- "Plot"
# germplasm <- read.csv(file="Referentiels/germplasm_Sinfonia.csv",
#                       header = TRUE,sep = ",",
#                       stringsAsFactors = FALSE,
#                       fileEncoding = "UTF-8-BOM")


convert2Op <- function(dat, metadataSO, SOtype, germplasm,data_r6, prefix_URI){
  dat <- dat[,colnames(dat) %in% metadataSO$prop_read[metadataSO[[SOtype]]]]
  #print(dat$Greffon)
  # define small code for SO type as prefix of SO URI
  ref <- data_r6$ref_file
  dat$type <- ref[[SOtype]][ref$Name == "Id1"]
  CodeType <- ref[[SOtype]][ref$Name == "Id3"]
  pref_SO_URI <- ref$prefix_SO_URI[ref$Name == "Id1"]
  if(prefix_URI != ""){
    pref <- paste0(pref_SO_URI,CodeType,"_",prefix_URI,"_")
  } else {
    pref <- paste0(pref_SO_URI,CodeType,"_")
  }


  ### adding information
  ## clean SO name
  #### dat$Nom <- janitor::make_clean_names(dat$Nom)
  dat$Nom <- gsub(dat$Nom, pattern=" ", replacement="_")
  ## SO uri if missing (else no change from user input)
  dat$uri[is.na(dat$uri)] <- tolower(paste0(pref,dat$Nom))
  ## change germplasm name to germplasm uri
  ## for germplasm
  if("Greffon" %in% colnames(dat)) {
    dat$Greffon <- plyr::mapvalues(dat$Greffon,from=germplasm$name,
                                   to=germplasm$uri,warn_missing = FALSE)
  }

  if("PorteGreffe" %in% colnames(dat)) {
    dat$PorteGreffe <- plyr::mapvalues(dat$PorteGreffe,from=germplasm$name,
                                       to=germplasm$uri,warn_missing = FALSE)
  }

  ## set date properties as date format
  if("DateCreation" %in% colnames(dat)){
    dat$DateCreation <- as.Date(dat$DateCreation,tryFormats="%d/%m/%Y")
  }
  if("DateDestruction" %in% colnames(dat)){
    dat$DateDestruction <- as.Date(dat$DateDestruction,tryFormats="%d/%m/%Y")
  }

  ### function type : to apply type function according to metadataSO file
  ## in order to convert automatically the data type of a col to the expected data type
  # for example, date are expected to be in AAAA-MM-DD format
  # positionX has to be numeric
  # etc.
  cols <- intersect(colnames(dat),metadataSO$prop_read[metadataSO$col_function != ""])
  for(c in cols){
    dat[,c] <- eval(parse(text=metadataSO$col_function[metadataSO$prop_read == c]))(dat[,c])
  }

  # change column names
  #selCols <- which(metadataSO$prop_read[metadataSO[[SOtype]]] %in% colnames(dat))
  colnames(dat) <- plyr::mapvalues(colnames(dat), from=metadataSO$prop_read,
                                   to=metadataSO$prop_SI,warn_missing = FALSE)
  dat <- janitor::remove_empty(dat, which="cols")
  ## transform NA in ""
  dat <- apply(dat, c(1,2),function(x){x <- ifelse(is.na(x),"",x)})
  # add one blank line
  dat <- as.data.frame(rbind(matrix(nrow=1,ncol=ncol(dat),NA,
                                    dimnames = list(rep(NA,1),colnames(dat))),dat))
  dat <- dplyr::rename(dat, URI=uri,Type=type, Name=name)
  rownames(dat) <- NULL

  return(dat)
}


#' Convert variable data frame
#'This function evaluates formula entered in corresp data frame and change values in userDF, according to column type (defined in variable data frame)
#'
#' @param corresp data frame of correspondence edited by the user
#' @param userDF initial data frame of data
#' @param variables data frame of variables, with details and format type (integer, date)
#'
#'
convertVarDF <- function(corresp,userDF, variables){
  #print("in vardf function")
  corresp$Var[corresp$Var == ""] <- NA
  corresp$Expr[corresp$Expr == ""] <- NA
  # remove rows without defined correspondence
  corresp <- corresp[corresp$Corr != "" &
                       !is.na(corresp$Corr),]
  var_cols <- corresp$Var[! corresp$Var %in% c(NA,"")]
  userDF_edit <- as.data.frame(userDF[,var_cols])
  colnames(userDF_edit) <- corresp$Corr[! corresp$Var %in% c(NA,"")]
  # add column name
  userDF_edit$Nom <- eval(parse(text=corresp$Expr[corresp$Corr == "Nom"]),
                          envir = userDF)
  # Add new columns with expression => when var is not defined by corr and expr does
  exprCols <- which(is.na(corresp$Var) &
                      !is.na(corresp$Corr) &
                      !is.na(corresp$Expr) &
                      # do not evaluate Nom & Date, already done in create_data_corresp
                      !corresp$Corr %in% c("Nom","Date"))
  #print(paste0("exprCols: ",exprCols))
  if(length(exprCols) > 0){
    for(i in 1:length(exprCols)){
      userDF_edit <- cbind(userDF_edit,
                           data.frame(
                             var=eval(parse(text=corresp$Expr[exprCols[i]]),
                                      envir=userDF)))
      colnames(userDF_edit)[colnames(userDF_edit) =="var"] <- corresp$Corr[exprCols[i]]
    }
  }

  variables$datatype <- gsub(variables$datatype, pattern="http://www.w3.org/2001/XMLSchema#",
                             replacement="")
  ##print(colnames(userDF_edit))
  # verify and coerce to variable format
  for(j in 1:ncol(userDF_edit)){
    var_j <- colnames(userDF_edit)[j]
    ##print(var_j)
    ## Date and Nom are already handled in create_data_corresp function
    if(var_j %in% c("Nom")){
      next
    } else if(var_j == "Date"){
      userDF_edit$Date <- NULL
      next
    } else{
      if(var_j %in% variables$name){
        # TODO: keep track of modified cell format
        if(nrow(variables[variables$name == var_j,]) > 1){
          warning(paste0("This variable correspond to several URIs: ",var_j))
        } else {
          #print(var_j)
          varType <- unique(variables$datatype[variables$name == var_j])
          if(varType == "decimal") {
            userDF_edit[,j] <- as.numeric(userDF_edit[,j])
          } else if(varType == "integer") {
            userDF_edit[,j] <- as.integer(userDF_edit[,j])
          } else if(varType == "string") {
            userDF_edit[,j] <- as.character(userDF_edit[,j])
          } else if(varType == "date") {
            userDF_edit[,j] <- as.character(lubridate::format_ISO8601(
              as.POSIXct(userDF_edit[,j],tz="UTC"),precision="ymd",usetz=FALSE))
          }
        }
      } else {
        warning(paste("This variable does not exist in OpenSilex:",var_j))
      }
    }

  }
  return(userDF_edit)
}



#' Create data correspondence
#'
#' @param corresp_data data frame of edited correspondence between column names and variable names
#' @param data user data
#' @param datSO table of scientific object, specific to the selected experiment and scientific object type
#' @param variables table of variables
#' @param moreCols character vector of
#' @param data_r6 R6 object class with several elements
#'
#' @return covarDFSO, table of SO id, covariables and variables

create_data_corresp <- function(corresp_data, data, datSO, variables,
                                moreCols=NULL, data_r6){
  # print("in create data corresp function")
  # print(moreCols)

  #print(paste0("nrow datSO in function: ",nrow(datSO)))
  #print("inside create_data_corresp")
  colnames(corresp_data) <- c("Var","Corr","Expr","Print")
  covarDF <- data.frame(Nom=eval(parse(text=corresp_data$Expr[corresp_data$Corr == "Nom"]),envir = data),
                        Date=eval(parse(text=corresp_data$Expr[corresp_data$Corr == "Date"]),envir = data),
                        `Millésime`=NA,
                        `StadesPhéno_BBCH`=NA,
                        Vin_StadeVinif=NA)
  covarDFSO <- merge(covarDF, datSO[,c("uri","name")],
                     by.x="Nom",by.y="name",all.x=TRUE,
                     incomparables=NA,sort=FALSE)
  ## set uri and Nom as first columns
  covarDFSO <- dplyr::relocate(covarDFSO, c("uri","Nom"))
  ## remove part of pattern for scientific object URI
  patt <- data_r6$ref_file$prefix_SO_URI[data_r6$ref_file$Name == "Id1"]
  covarDFSO$uri <- gsub(x=covarDFSO$uri, pattern=patt,replacement = "")

  ## function from fct_helpers.R
  varDF <- convertVarDF(corresp=corresp_data,
                        userDF=data,
                        variables=variables)

  # print(head(varDF))
  # print("convertVarDF end")
  ## add first new cols to varDF() if asked by user
 # if(!is.null(moreCols) && length(moreCols) > 0 && !is.na(moreCols)){
    if(!all(is.na(moreCols))){
    for(c in moreCols){
      varDF <- cbind(data[[c]],varDF)
      colnames(varDF)[1] <- c
    }
  }
  ##print(paste("ncolvarDF:",ncol(varDF)))
  # merge with variable DF
  covarDFSO <- merge(covarDFSO,varDF,all=TRUE,incomparables=NA,
                     sort=FALSE,by="Nom")
  ##print(head(covarDFSO))
  ## remove empty rows for variables columns
  varcols <- intersect(variables$name, colnames(varDF))

  if(length(varcols) > 1){
    idx <- which(rowSums(is.na(covarDFSO[,varcols])) == length(varcols))
  } else if(length(varcols) == 1){
    idx <- which(is.na(covarDFSO[,varcols]), arr.ind=TRUE)
  }
  if(length(idx) != 0){
    covarDFSO <- covarDFSO[-idx,]
  }
  covarDFSO <- janitor::remove_empty(covarDFSO,which="rows")
  covarDFSO$Date <- as.character(covarDFSO$Date)
  ##print(paste0("ncol covarDFSO function:",ncol(covarDFSO)))
  return(covarDFSO)
}



convertDatOp <- function(editDF,variables, BBCH_table,modify_dates,data_r6){
  ##print("inside convertDatOp function")
  # remove columns filled with NAs
  editDF <- janitor::remove_empty(editDF, which="cols")
  #print(colnames(editDF))

  # remove rows when URI is not filled
  editDF <- editDF[!is.na(editDF$uri),]

  ## remove rows with only NAs
  varCols <- setdiff(colnames(editDF), c("Nom","uri","Date","Millésime","StadesPhéno_BBCH"))
  #print(varCols)
  idx <- apply(editDF[,varCols,drop=FALSE],1,function(x) all(is.na(x)))
  idx <- which(idx, arr.ind = TRUE)
  #print(idx)
  if(length(idx) > 0){
    editDF <- editDF[-idx,]
  }

  # convert BBCH scale into numbers
  editDF$`StadesPhéno_BBCH` <- plyr::mapvalues(editDF$`StadesPhéno_BBCH`,
                                               from=BBCH_table$label,
                                               to=BBCH_table$number,
                                               warn_missing = FALSE)

  ## rebuild full uri name
  prefixURI <- data_r6$ref_file$prefix_SO_URI[data_r6$ref_file$Name == "Id1"]
  #cat(prefixURI)
  editDF$uri <- paste0(prefixURI,editDF$uri)
  # add uri for variables
  colnames(editDF) <- plyr::mapvalues(colnames(editDF),
                                      from=variables$name,
                                      to=variables$uri,warn_missing = FALSE)
  # reorder columns by putting variables at the end
  editDF$Nom <- NULL
  editDF$Date <- lubridate::format_ISO8601(
    as.POSIXct(editDF$Date,tryFormats=c("%d/%m/%Y","%Y-%m-%d"),
               tz="GMT"),precision="ymdhms",usetz = TRUE)
  if(modify_dates){
    # identity number of repetition for each SO
    editDF$id <- paste0(editDF$uri,editDF$Date)
    for(i in unique(editDF$id)){
      idx <- which(editDF$id == i, arr.ind=TRUE)
      # add seconds for duplicated measures
      editDF$Date[editDF$id == i] <-
        lubridate::format_ISO8601(as.POSIXct(editDF$Date[editDF$id == i]) +
                                    lubridate::seconds(seq(length(idx))),
                                  precision="ymdhms",usetz = TRUE)

    }
    editDF$id <- NULL
  }
  editDF <- dplyr::relocate(editDF, c("uri","Date"))
  #if(instance == "VitisExplorer"){
  colnames(editDF)[colnames(editDF) == "uri"] <- "target"
  #   editDF[["Millésime"]] <- NULL
  # }

  # add blank line
  DFfinal <- dplyr::bind_rows(dplyr::bind_rows(rlang::set_names(rep(NA, ncol(editDF)), colnames(editDF)),
                                               rlang::set_names(rep(NA, ncol(editDF)), colnames(editDF))),
                              editDF)
  return(DFfinal)
}


#' Verify bounds of data variables
#'
#' @param dat user data with variable correspondence
#' @param valDF validation variable data frame
#' @param varCol column name of valDF to use: "name" or "uri"
#'
#' @return data frame of cell coordinates and color to highlight

verifDatBounds <- function(dat,valDF,varCol="name"){
  # identity rows and columns to color in red
  list_red <- list() ; list_orange <- list()
  dat <- as.data.frame(dat)
  for(c in intersect(colnames(dat),valDF[[varCol]])){
    cond_red1 <- c();cond_red2 <- c()
    # min value
    if(!is.na(valDF$minValue[valDF[[varCol]] %in% c] )){
      cond_red1 <- which(dat[,c] < valDF$minValue[valDF[[varCol]] %in% c],
                         arr.ind=TRUE)
    }
    # max value
    if(!is.na(valDF$maxValue[valDF[[varCol]] %in% c])){
      cond_red2 <- which(dat[,c] > valDF$maxValue[valDF[[varCol]] %in% c],
                         arr.ind=TRUE)
    }
    cond_red <- c(cond_red1,cond_red2)

    ## compute df for red if any extra values found
    if(length(cond_red) > 0){
      list_red[[c]] <- data.frame(col=which(colnames(dat) %in% c,arr.ind=TRUE),
                                  row=cond_red)
    }

    # same for orange color (warning)
    cond_orange1 <- c() ; cond_orange2 <- c()
    if(!is.na(valDF$lwrBound[valDF[[varCol]] %in% c] )){
      cond_orange1 <- which(dat[,c] < valDF$lwrBound[valDF[[varCol]] %in% c],
                            arr.ind=TRUE)
    }
    if(!is.na(valDF$uprBound[valDF[[varCol]] %in% c])){
      cond_orange2 <- which(dat[,c] > valDF$uprBound[valDF[[varCol]] %in% c],
                            arr.ind=TRUE)
    }
    cond_orange <- c(cond_orange1, cond_orange2)
    if(length(cond_orange) > 0){
      list_orange[[c]] <- data.frame(col=which(colnames(dat) %in% c,arr.ind=TRUE),
                                     row=cond_orange)
    }
  }

  if(length(list_red) > 0){
    df_red <- do.call(rbind, list_red)
    df_red$color <- "red"
  } else {
    df_red <- NULL
  }
  if(length(list_orange) > 0){
    df_orange <- do.call(rbind, list_orange)
    df_orange$color <- "orange"
  } else {
    df_orange <- NULL
  }
  df <- rbind(df_orange, df_red)
  # # remove rows present twice, keep "red" information
  if(!is.null(df)){
    idx <- which(duplicated(df[,c("row","col")]) | duplicated(df[,c("row","col")],
                                                              fromLast=TRUE),arr.ind=TRUE)
    if(length(idx) > 0){
      df <- df[-idx[df$color[idx] == "orange"],]
    }
  } else {
    df <- data.frame(col=0, row=0,color="green")
  }
  #print(df)
  return(df)
}



#' Generate column rendering text
#'
#' @param df data frame of cells to highlight with color. Contains columns "row" and "col" to indicate coordinates, and "color".

colRender <- function(df){
  #print(df)
  ##print("inside colRender function")
  # create text
  txt <- ""
  for(i in 1:nrow(df)){
    txt <- paste0(txt, "if (col === ",(df$col[i]-1),
                  " && row === ",(df$row[i]-1),"){td.style.background = '",
                  df$color[i],"';}")
  }
  txt <- paste0("function (instance, td, row, col, prop, value, cellProperties) {
                   Handsontable.renderers.NumericRenderer.apply(this, arguments);
                ",txt,"}")
  #print(txt)
  return(txt)
}


#' Highlight text in table
#'
#' @param searchText string with words to search
#' @param where2findDF data frame to search for
#' @param cols2find index of columns in where2findDF to search for, default to all character columns
#' @return a logical vector (TRUE/FALSE) for the selected lines in where2findDF according to searchText (all lines displayed if no text is entered)

F_searchText <- function(searchText = "", where2findDF, cols2find=NULL) {
  #print(paste0("ncol where2findDF: ",ncol(where2findDF)))
  if(is.null(cols2find)){
    cols2find <- seq(ncol(where2findDF))
    #cols2find <- as.numeric(which(apply(where2findDF,2,class) == "character"))
  }
  #print(paste0("cols2find: ",cols2find))

  indexRows <- rep(TRUE, nrow(where2findDF))
  if(searchText == "") {
    return(indexRows)
  }  else {
    searchTexts <- unlist(strsplit(searchText, split = " "))
    searchTexts <- iconv(searchTexts, to="ASCII//TRANSLIT")
    ## suppress all accent in characters
    for (i in cols2find){
      where2findDF[,i] <- iconv(where2findDF[,i], from="UTF-8",to="ASCII//TRANSLIT")
    }
    for (i in 1:length(searchTexts)){
      ir <- vector()
      for (j in cols2find){
        ir <- c(ir,grep(searchTexts[i], where2findDF[,j],ignore.case = TRUE))
      }
      ir <- seq(nrow(where2findDF)) %in% unique(ir)
      indexRows <- indexRows & ir
    }
    #print(sum(indexRows))
    return(indexRows)
  }
}


#' Get all genotypes with detailed information
#'
#' @param host url of the hosting opensilex service
#' @param user opensilex user
#' @param password opensilex user's password
#'
#' @return data frame of all germplasm with detailed information
#' @seealso `get_germplasm_info`, `get_germplasm_attr`
#'
get_all_genos_details <- function(host, user, password){
  ## get_token function in utils_helpers.R
  token <- get_token(host=host, user=user,password=password)
  ## get all genotypes uri
  GEN = httr::GET(paste0(host,"/core/germplasm"),
                  query = list(page_size = 10000),#,page=1),
                  httr::content_type_json(),encode ="raw",
                  config=httr::add_headers(Authorization=token))
  ##dim(dfGEN)
  dfGEN = jsonlite::fromJSON(rawToChar(GEN$content))$result
  # dfGEN
  dfGEN <- jsonlite::flatten(as.data.frame(dfGEN))
  dfGEN<- tidyr::unnest(dfGEN, colnames(dfGEN)[sapply(dfGEN, class)=="list"],
                        keep_empty = TRUE)

  ## get all possible attributes
  gen_attr <- get_germplasm_attr(token=token,host=host)

  ## seek attributes for all genotypes
  gen_info <- c("uri","rdf_type","name","species_name", "code",
                "website", gen_attr)
  df_geno_details <- get_germplasm_info(host=host,user=user,password=password,
                                        germplasm_uri=dfGEN$uri,
                                        infos =gen_info)

  result_geno_details <- merge(dfGEN, df_geno_details,
                               by=intersect(colnames(dfGEN),colnames(df_geno_details)),
                               all.x=TRUE)
  return(result_geno_details)

}


#' Get the list pf germplasm attributes
#'
#' @param token token generated by `get_token` function, not permanent.
#' @param host url of the OpenSilex host
#'
#' @return data frame with all attributes for the selected OpenSilex instance

get_germplasm_attr <-function(token,host){
  url <- paste0(host,"/core/germplasm/attributes")
  get_res <- httr::GET(url, httr::add_headers(Authorization = token))
  res_df <- httr::content(get_res, "text",encoding="UTF-8")
  attr <- jsonlite::fromJSON(res_df, flatten = TRUE)$result
  return(attr)
}

#' Extract germplasm information
#'
#' @param host url of the hosting opensilex service
#' @param user opensilex user
#' @param password opensilex user's password
#' @param germplasm_uri character vector of germplasm uris
#' @param infos columns of information to extract from germplasm
#' @seealso `get_germplasm_attr`

get_germplasm_info <- function(host, user, password,
                               germplasm_uri,
                               infos=c("uri","rdf_type","name")){

  token <- get_token(host = host, user = user,password = password)

  ## load list of germplasm attributes with this internal function
  attr <- get_germplasm_attr(token=token, host=host)

  genos_info_all <- c("uri","rdf_type","name","species_name", "code",
                      "website",attr)
  stopifnot(all(infos %in% genos_info_all))

  df_geno <- as.data.frame(matrix(nrow=1, ncol=length(genos_info_all), NA))
  colnames(df_geno) <- genos_info_all


  for(gen_uri in germplasm_uri){
    url <- paste0(host,"/core/germplasm/",utils::URLencode(gen_uri,reserved=TRUE))
    get_result <- httr::GET(url, httr::add_headers(Authorization = token))
    get_result_text <- httr::content(get_result, "text",encoding="UTF-8")
    res_json <- jsonlite::fromJSON(get_result_text, flatten = TRUE)$result

    metadata <- res_json$metadata
    res_json$metadata <- NULL
    ## info in an outer list
    res_json_info <- do.call(cbind, res_json)
    if(is.null(metadata)){
      tmp <- cbind(res_json_info)
    } else {
      ## extract info from res_json
      ### metadata in a inner list
      res_json_meta <- do.call(cbind,metadata)
      tmp <- cbind(res_json_info,res_json_meta)
    }

    # set NULL elements
    cols2add <- setdiff(infos,colnames(tmp))
    tmp <- cbind(tmp, setNames(as.data.frame(matrix(ncol=length(cols2add),nrow=1,NA)),cols2add))

    df_geno <- plyr::rbind.fill(df_geno[,infos],tmp[,infos])
  }
  df_geno <- as.data.frame(apply(df_geno, 2, unlist))


  return(df_geno[-1,infos])

}
