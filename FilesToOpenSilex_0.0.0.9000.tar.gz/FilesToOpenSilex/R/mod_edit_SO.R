#' edit_SO UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
mod_edit_SO_ui <- function(id){
  ns <- NS(id)
  tagList(

    fluidPage(
      fluidRow(
        bs4Dash::box(width=8,
                     title="Tableau à éditer si nécessaire",
                     height="1000px",
                     closable = FALSE,
                     maximizable = TRUE,
                     style = "overflow-y: scroll",
                     status="danger",
                     textInput(ns("prefixURI"),label="Préfixe à ajouter à l'URI",value="", width="200px"),
                     rhandsontable::rHandsontableOutput(ns("edit_rht_os2")),
                     ##verbatimTextOutput(ns("render")),
                     #DT::dataTableOutput("tableSO2"),
                     br(),
                     shinyWidgets::actionBttn(ns("valcorrOS"),"Valider",
                                              color="warning", size="md", style="fill"),
                     downloadButton(ns("DWNLD_SO2"),"Télécharger le fichier")

        ),
        bs4Dash::box(width=4,
                     title=" Aide remplissage",
                     maximizable = TRUE,
                     status="info",
                     icon=icon("question"),
                     style = "overflow-x: scroll",
                     p("Vérification des noms de germplasm (couleur = bonne / mauvaise correspondance)"),
                     p("Edition à la main des colonnes si nécessaire"),
                     br(),
                     p("Il est possible de supprimer des lignes en faisant ",
                       code("Clic droit + "),em("Remove row")),
                     br(),
                     p("Ne pas oublier de valider à la fin")
        )
      )
    )
  )
}

#' edit_SO Server Functions
#' This module creates the correspondence file to be edited by hand, using rhandsontable and
#' create the dataframe with replaced column names
#'
#' @param id shiny module id
#' @param germplasm  data frame of germplasm in OpenSilex
#' @param metadataSO data frame with properties associated with type of scientific objects
#' @param data_r6 R6 object, containing object "edit_SO_1" with edited correspondence
#'
#' @noRd
mod_edit_SO_server <- function(id, germplasm,metadataSO,data_r6){
  moduleServer( id, function(input, output, session){
    ns <- session$ns
    ##output$render <- renderPrint(colRender(data_r6$colRender_SO_1()))

    # use rhandsontable to edit correspondence table using formula to be evaluated
    output$edit_rht_os2 <- rhandsontable::renderRHandsontable({

      rhot <- rhandsontable::rhandsontable(data_r6$edit_SO_1(),
                                           row_highlight =data_r6$colRender_SO_1()$row-1,
                                           col_highlight =data_r6$colRender_SO_1()$col-1,
                                           #useTypes = FALSE, ## prevent from renderer to print if uncommented
                                           contextMenu = TRUE,
                                           manualColumnResize = TRUE,
                                           highlightCol = TRUE,
                                           highlightRow = TRUE
      ) %>%
        rhandsontable::hot_cols(renderer=colRender(df=req(data_r6$colRender_SO_1())),
                                halign="htCenter") %>%
        rhandsontable::hot_context_menu(allowRowEdit = TRUE,allowColEdit = FALSE)

      ## to attribute col_type and col_source to each metada
      #### for each column name of metadata in DF
      metadata2edit <- colnames(data_r6$edit_SO_1())[colnames(data_r6$edit_SO_1()) %in% metadataSO$prop_read]
      for (met in metadata2edit) {
        # only if col_type is defined: date, numeric, checkbox or dropdown
        if (metadataSO$col_type[metadataSO$prop_read == met] != "" ) {
          #print(met)
          rhot <- rhandsontable::hot_col(rhot, halign="htCenter",
                                         col=met,
                                         # definition of type according to metadataSO
                                         type = as.character(metadataSO$col_type[metadataSO$prop_read==met]),
                                         # definition of source according to metadataSO (e.g list of germplasm)
                                         source = eval(parse(text=metadataSO$col_source[metadataSO$prop_read==met])))
        } else {
          rhot <- suppressWarnings(rhandsontable::hot_col(rhot,col=met,type=NULL))
        }
      }
      return(rhot)
    }) # end rhandsontable

    # output$tableSO2 <- DT::renderDataTable({rhandsontable::hot_to_r(input$edit_rht_os2)})

    ## Local download for user
    output$DWNLD_SO2 <- downloadHandler(
      filename = paste0("corresp_SO2",format(Sys.time(),"%Y-%m-%d_%H%M"),".csv"),
      content = function(fname){
        write.csv(req(rhandsontable::hot_to_r(input$edit_rht_os2)),
                  fname, row.names=FALSE, fileEncoding = "UTF-8")
      }
    )

    observeEvent(input$valcorrOS,{
      ## use convert2Op function from fct_helpers.R
      #print(data_r6$SOtype)
      sinFile <- reactive({
        convert2Op(dat=req(rhandsontable::hot_to_r(input$edit_rht_os2)),
                   #prefix="Col",#input$prefix,
                   SOtype=data_r6$SOtype(),
                   metadataSO=metadataSO,
                   germplasm=germplasm,
                   data_r6=data_r6,
                   prefix_URI=input$prefixURI)
      })
      data_r6$finalSO <- reactive(req(sinFile()))
    })
    return(data_r6)
  })
}


## To be copied in the UI
# mod_edit_SO_ui("edit_SO_1")

## To be copied in the server
# mod_edit_SO_server("edit_SO_1")
