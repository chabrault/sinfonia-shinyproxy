#' edit_data UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
mod_edit_data_ui <- function(id){
  ns <- NS(id)
  tagList(
    fluidRow(
      bs4Dash::box(width=12,
                   height="1000px",
                   title="Tableau à modifier",
                   closable = FALSE,
                   maximizable = TRUE,
                   status="danger",
                   style = "overflow-x: scroll;overflow-y: scroll",
                   p("Vérification de la correspondance et test des limites des variables et des noms des objets scientifiques"),
                   p("Ne pas oublier de définir une date"),

                   shinyWidgets::actionBttn(ns("preview"),"Tester limites",
                                            color="warning",size="md", style="fill"),
                   br(),
                   rhandsontable::rHandsontableOutput(ns("edit_rht_dat2")),
                   br(),
                   downloadButton(ns("DWNLD_DAT2"),"Télécharger le fichier")

      )
    )
  )
}

#' edit_data Server Functions
#'
#' @noRd
mod_edit_data_server <- function(id,data_r6,inputDFvar, BBCH_table,
                                 modify_dates){
  moduleServer( id, function(input, output, session){
    ns <- session$ns
    observeEvent(input$preview, {
      msg <- "Noms corrects ?"
      type <- "warning"
      if(all(nrow(data_r6$df_colRender()) == 1 & data_r6$df_colRender()$color == "green")){
        msg <- "Tout est parfait !"
        type <- "success"
      } else {
        msg_o <- "" ; msg_r <- ""
        if(any(data_r6$df_colRender()$color == "orange")){
          msg_o <- paste(sum(data_r6$df_colRender()$color == "orange"),
                         "ligne(s) affiche(nt) des valeurs douteuses")
          type <- "warning"
        }
        if(any(data_r6$df_colRender()$color == "red")){
          msg_r <- paste(sum(data_r6$df_colRender()$color == "red"),
                         "ligne(s) affiche(nt) des valeurs aberrantes")
          type <- "error"
        }
        msg <- paste0(msg_o, msg_r)
      }

      # Show a modal when the button is pressed
      shinyalert::shinyalert(title="Test des valeurs du tableau",
                             text=msg, type = type)
    })

    ## remove part of pattern for scientific object URI
    patt <- data_r6$ref_file$prefix_SO_URI[data_r6$ref_file$Name == "Id1"]
    #cat(patt)

   ## observeEvent(data_r6$covarDFSO,{

    ## use rhandsontable to edit covariables
    output$edit_rht_dat2 <- rhandsontable::renderRHandsontable({
      editDat2 <- req(data_r6$covarDFSO()) %>%
        rhandsontable::rhandsontable(height=700,width=1300) %>%
        rhandsontable::hot_table(overflow="visible",highlightCol=TRUE,
                                 highlightRow=TRUE) %>%
        rhandsontable::hot_col(col="Date",type="date") %>%
        rhandsontable::hot_col(col="uri",type="dropdown",
                               source=c("",gsub(x=req(data_r6$datSO()$uri),
                                                pattern=patt,replacement="")),strict=FALSE) %>%
        rhandsontable::hot_col(col="Millésime",type="dropdown",source=c(2011:2023)) %>%
        rhandsontable::hot_col(col="StadesPhéno_BBCH",type="dropdown",
                               source=c("",BBCH_table$label)) %>%
        rhandsontable::hot_col(col="Vin_StadeVinif",type="dropdown",
                               source=c("","encuvage","débourbage","fin FA","fin FML","vin stable","bouteille")) %>%
        rhandsontable::hot_cols(manualColumnResize=TRUE) %>%
        ## colRender is a function from fct_helpers.R
        rhandsontable::hot_cols(renderer=colRender(df=req(data_r6$df_colRender())),
                                halign="htCenter",valign="htMiddle") %>%
        ### line above needed to display the selector on dropdown cols
        rhandsontable::hot_col(2:6,renderer = "function (instance, td, row, col, prop, value, cellProperties) {
                Handsontable.renderers.DropdownRenderer.apply(this, arguments)}")

      ## set minimal width to columns of covariables not consistent with type of scientific object
      # if (data_r6$SOtype() != "Wine") {
      #   editDat2 <- editDat2 %>% rhandsontable::hot_col(6, width = 0.5)
      # }
      # if (data_r6$SOtype() == "Wine") {
      #   editDat2 <- editDat2 %>% rhandsontable::hot_col(4:5, width = 0.5)
      # }
      editDat2
    })



    ## Local download for user
    output$DWNLD_DAT2 <- downloadHandler(
      filename = paste0("corresp_DAT2",format(Sys.time(),"%Y-%m-%d_%H%M"),".csv"),
      content = function(fname){
        write.csv(req(rhandsontable::hot_to_r(input$edit_rht_dat2)),
                  fname, row.names=FALSE, fileEncoding="UTF-8")
      }
    )

    return(list(
      Dat2=reactive(req(rhandsontable::hot_to_r(input$edit_rht_dat2)))
    ))
   ## }, ignoreInit=FALSE)


  })
}

## To be copied in the UI
# mod_edit_data_ui("edit_data_1")

## To be copied in the server
# mod_edit_data_server("edit_data_1")
