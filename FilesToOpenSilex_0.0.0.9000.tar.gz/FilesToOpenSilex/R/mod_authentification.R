#' authentification UI Function
#'
#' @description The UI part of the module handling the connection to an opensilex instance. Return a token
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @export
#' @importFrom shiny NS tagList textInput passwordInput actionButton verbatimTextOutput

mod_authentification_ui <- function(id) {
  ns <- NS(id)
  fluidPage(
    h4("Connexion à OpenSilex nécessaire pour télécharger les fichiers mis à jour"),
    sidebarLayout(
      sidebarPanel(
        #    shiny::textInput(NS(id, "host"), "Host", value = default_host),
        shiny::textInput(ns("user"), "Identifiant"),
        shiny::passwordInput(ns("password"), "Mot de passe"),
        shinyWidgets::actionBttn(ns("connectBtn"),
                                 "Connexion à OpenSilex",
                                 color="royal", style="jelly"),
        shiny::verbatimTextOutput(ns("terminal"))
        # mod_get_token_ui(ns("get_token_1")),

      ),
      mainPanel(
        p("La mise à jour du matériel génétique ne fonctionne pas pour Sinfonia"),
        br(),
        shinyWidgets::actionBttn(ns("majVar"), "Mise à jour des variables à partir d'OpenSilex",
                                 color="danger",style="gradient"),
        mod_update_var_ui(ns("update_var_1")),
        br(),
        shinyWidgets::actionBttn(ns("majOS"), "Mise à jour des objets scientifiques à partir d'OpenSilex",
                                 color="danger",style="gradient"),
        mod_update_so_ui(ns("update_so_1")),
        br(),
        shinyWidgets::actionBttn(ns("majGEN"), "Mise à jour des ressources génétiques à partir d'OpenSilex",
                                 color="danger",style="gradient"),
        mod_update_geno_ui(ns("update_geno_1"))

      )
    )

  )
}


#' authentification Server Functions
#'
#' @description The server part of the module handling the connection to an opensilex instance.
#' @param id Internal parameter for {shiny}.
#' @return A named list with various reactive values
#' \describe{
#'  \item{connect}{A function handling the connection to an Opensilex WebAPI}
#' }
#' @export
#' @importFrom shiny renderPrint reactive observeEvent
#' @importFrom evaluate try_capture_stack evaluate
#' @importFrom utils capture.output
#' @importFrom httr GET POST content_type_json add_headers
#' @importFrom jsonlite fromJSON
#' @import dplyr
#' @importFrom methods is
#### The name of this module is confusing because it already exists in opensilexR and in VitisExploApp without doing the same thing
mod_authentification_server <- function(id,instance,data_r6) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns

    host <- data_r6$ref_file$Authentification[data_r6$ref_file$Name == "Id1"]
    user <- data_r6$ref_file$Authentification[data_r6$ref_file$Name == "Id2"]
    # password <- data_r6$ref_file$Authentification[data_r6$ref_file$Name == "Id3"]

    get_token_mod <- function() {
      cat('Connecting...\n')
      cat('User: ', input$user, '\n')
      cat('url: ', host, '\n')
      token <- evaluate::try_capture_stack(
        # utils::capture.output(
        ### get_token defined in utils_helpers.R
        get_token(
          host = host,
          user = req(input$user),
          password = req(input$password)
        )
        # )
        ,
        environment()
      )
      # print("token")
      # print(class(token))
      # print(token)
      if (methods::is(token,"character")) {
        output$terminal <- shiny::renderPrint({
          cat('Token retrieved !\n')
          cat(token)
        })
        return(token)
      } else {
        output$terminal <- shiny::renderPrint({
          ## base::message send text to sderr, triggering an error state
          message(
            'Something went wrong. Check your credentials then the logs')
          message(token)
        })
        output$terminal <- shiny::renderPrint({
          message(token)
        })
        return(NULL)
      }
    } # end get_token_mod function

    observeEvent(input$connectBtn,{
      get_token_mod()
    })
    # connect <- shiny::reactive({
    #   attempt_connect() ## don't know which function it is
    # })

    #token <- ""

    if(!is.null(instance)){
      shiny::observeEvent(c(input$majVar), {
        mod_update_var_server("update_var_1",host=host,
                              user=input$user, password=input$password,
                              data_r6=data_r6)

      },ignoreInit = TRUE)

      shiny::observeEvent(c(input$majOS), {
        mod_update_so_server("update_so_1",host=host,
                             user=input$user, password=input$password,
                             data_r6=data_r6)
      },ignoreInit = TRUE)

      shiny::observeEvent(c(input$majGEN), {

        mod_update_geno_server("update_geno_1",host=host,user=input$user,
                               password=input$password,data_r6=data_r6)
      },ignoreInit = TRUE)
    }

    return(list(
      connect = NULL#connect
    ))
    #   },ignoreInit = TRUE)
    # })

  })
}

