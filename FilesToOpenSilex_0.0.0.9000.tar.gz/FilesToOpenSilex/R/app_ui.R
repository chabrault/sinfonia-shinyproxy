#' The application User-Interface
#'
#' @param request Internal parameter for `{shiny}`.
#'     DO NOT REMOVE.
#' @import shiny
#' @importFrom bs4Dash bs4DashPage dashboardHeader bs4DashSidebar bs4SidebarHeader sidebarMenu bs4SidebarMenu bs4SidebarMenuItem bs4SidebarMenuSubItem dashboardBody tabItem bs4TabItem bs4TabItems tabItems
#' @noRd
app_ui <- function(request) {
  tagList(
    # Leave this function for adding external resources
    golem_add_external_resources(),


    bs4DashPage(skin="light",# = "purple",
                fullscreen = TRUE,
                header=dashboardHeader(title="FilesToOpenSilex",
                                       controlbarIcon=shiny::icon("circle", verify_fa = FALSE)),

                # ----------- SIDEBAR ------------- #
                sidebar=bs4DashSidebar(
                  collasped=FALSE,
                  expandOnHover=TRUE,
                  fixed=TRUE,
                  # bs4SidebarHeader("Menu"),

                  bs4SidebarMenu(
                    bs4SidebarMenuItem("Chargement tableau",
                                       tabName="TabUpload",icon=icon("upload")),
                    bs4SidebarMenuItem("Ajout objet scientifique",tabName="TabSO",
                                       bs4SidebarMenuSubItem("1. Correspondance",tabName="SO1"),
                                       bs4SidebarMenuSubItem("2. Modification",tabName="SO2"),
                                       bs4SidebarMenuSubItem("3. Fichier formaté",tabName="SO3")
                    ),
                    bs4SidebarMenuItem("Ajout données",tabName="TabData",
                                       bs4SidebarMenuSubItem("1. Correspondance",tabName="DAT1"),
                                       bs4SidebarMenuSubItem("2. Modification",tabName="DAT2"),
                                       bs4SidebarMenuSubItem("3. Fichier formaté",tabName="DAT3")
                    ),
                    bs4SidebarMenuItem("Référentiels",tabName="TabRef",
                                       bs4SidebarMenuSubItem("Matériel végétal",tabName="REF1"),
                                       bs4SidebarMenuSubItem("Objets scientifiques",tabName="REF2"),
                                       bs4SidebarMenuSubItem("Variables",tabName="REF3"),
                                       bs4SidebarMenuSubItem("Limites variables",tabName="REF4"),
                                       bs4SidebarMenuSubItem("Liste tableaux",tabName="REF5"),
                                       bs4SidebarMenuSubItem("Admin",tabName="REF6")
                    )
                  )
                ), #bs4DashSidebar
                # ----------- BODY ------------- #
                ## Menu load data
                body=bs4Dash::bs4DashBody(
                  bs4TabItems(
                    bs4TabItem(tabName = "TabUpload",
                               shiny::fluidPage(
                                 tags$a(href="https://github.com/chabrault/fto_files/archive/refs/heads/master.zip",
                                        "Fichiers sources (Github)"),
                                 uiOutput("instance_ui"),
                                 #shinyjs::useShinyjs(),

                                 conditionalPanel("input.instance!=''",
                                                  mod_import_table_ui("import_table_1")
                                                  ),
                                 #mod_import_table_ui("import_table_1")

                               )
                    ),

                    ## Menu scientific object
                    bs4TabItem(tabName = "SO1",
                               mod_corresp_SO_ui("corresp_SO_1")
                    ),
                    bs4TabItem(tabName = "SO2",
                               mod_edit_SO_ui("edit_SO_1")
                    ),
                    bs4TabItem(tabName = "SO3",
                               fluidPage(
                                 column(width=12,
                                        h4("Finalisation de l'importation des données dans OpenSilex"),

                                        column(12,
                                               DT::dataTableOutput("tab_SOfinal"),
                                               style = "height:800px; width:95%; overflow-y: scroll;overflow-x: scroll;"
                                        ),
                                        h4("Téléchargement du fichier pour OpenSilex"),
                                        br(),
                                        downloadButton("download_final","Télécharger tableau")
                                 )
                               )
                    ),

                    ## Menu data
                    bs4TabItem(tabName = "DAT1",
                               tagList(
                                 mod_corresp_data_ui("corresp_data_1"),
                               )
                    ),
                    bs4TabItem(tabName = "DAT2",
                               mod_edit_data_ui("edit_data_1"),
                    ),
                    bs4TabItem(tabName = "DAT3",
                               fluidPage(
                                 h4("Finalisation de l'importation des données dans OpenSilex"),
                                 # widget to change date for repeated measures
                                 h5("Cliquer sur le bouton si l'unicité de l'objet scientifique, de la date et de la variable n'est pas assuré (mesures répétées pour une même variable et un même objet à une même date)"),
                                 shinyWidgets::switchInput(inputId="modify_dates",
                                                           label="Forcer horodatage unique"),
                                 #DT::dataTableOutput("tableDataFinal"),
                                 rhandsontable::rHandsontableOutput("tableDataFinal"),
                                 #actionButton("saveTableDatFinal","Enregistrer"),
                                 h4("Sauvegarder le tableau pour l'insérer dans OpenSilex"),
                                 shiny::downloadButton("downloadTableDatFinal","Télécharger le fichier")
                               )
                    ),
                    ## Menu references
                    bs4TabItem(tabName = "REF1",
                               reactable::reactableOutput("tabGerm")
                    ),
                    bs4TabItem(tabName = "REF2",
                               reactable::reactableOutput("tabSO")
                    ),
                    bs4TabItem(tabName = "REF3",
                               reactable::reactableOutput("tabVAR")
                    ),
                    bs4TabItem(tabName = "REF4",
                               mod_edit_var_bounds_ui("edit_var_bounds_1")
                    ),
                    bs4TabItem(tabName = "REF5",
                               fluidPage(
                                 column(width=12,
                                        shiny::selectInput("refFile", "Référentiel :",
                                                           choices=c("StadesPheno","Levures"),
                                                           selected="Levures"),
                                        ##shiny::actionButton("saveRefFile","Mise à jour du référentiel"),
                                        shiny::downloadButton("downloadRefFile","Télécharger le référentiel"),
                                        ##rhandsontable::rHandsontableOutput("tabRef")
                                        DT::dataTableOutput("tabRef"),
                                        style = "height:900px; width:100%; overflow-y: scroll;overflow-x: scroll;"
                                 )
                               )
                    ),
                    bs4TabItem(tabName = "REF6",
                               fluidPage(
                                 column(width=12,
                                        mod_authentification_ui("auth")
                                 )
                               )
                    )

                  ) # tabItems
                ) # dashboard body
    ) # dashboardpage
  ) #tagList
}

#' Add external Resources to the Application
#'
#' This function is internally used to add external
#' resources inside the Shiny application.
#'
#' @import shiny
#' @importFrom golem add_resource_path activate_js favicon bundle_resources
#' @noRd
golem_add_external_resources <- function() {
  add_resource_path(
    "www",
    app_sys("app/www")
  )
  add_resource_path(
    'img', app_sys('app/img'))
  add_resource_path(
    'sinfonia', app_sys('app/sinfonia'))

  tags$head(
    favicon(ico="favicon",
            resources_path = "www",
            ext="png"),
    bundle_resources(
      path = app_sys("app/www"),
      app_title = "FilesToOpenSilex"
    )
    # Add here other external resources
    # for example, you can add shinyalert::useShinyalert()
  )
}
