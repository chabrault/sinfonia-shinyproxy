#' The application server-side
#'
#' @param input,output,session Internal parameters for {shiny}.
#'     DO NOT REMOVE.
#' @import rhandsontable
#' @import formattable
#' @import dplyr
#' @importFrom data.table fread
#' @noRd
#'
app_server <- function(input, output, session) {
  shiny::shinyOptions(bootstrapTheme = bslib::bs_theme(version = 4L))

  # create R6 object to store data
  data_r6 <- R6::R6Class(
    "dataInR6",
    public = list(
      #instance=NULL,#isolate(req(input$instance)),
      import=NULL,
      edit_SO_1=NULL,
      colRender_SO_1=NULL,
      covarDFSO=NULL,
      datSO=NULL,
      list_files=NULL,
      ref_file=NULL,
      moreCols=NULL,
      datSO_all=NULL
    )
  )
  #data_r6$instance <- reactive(req(input$instance))
  observe(print(paste0("selected instance: ",input$instance)))

  ### All variables ###
  inputDFvar <- shiny::reactiveValues(
    variables=NULL,
    ValFile = NULL,
    corresp_var=NULL
  )



  ## ----------- Load external files saved Github ---------------

  req <- httr::GET("https://api.github.com/repos/chabrault/fto_files/git/trees/master?recursive=1")
  httr::stop_for_status(req)
  filelist <- unlist(lapply(httr::content(req)$tree, "[", "path"), use.names = F)
  ## filelist: character vector of directories and files
  instances <- unique(unlist(lapply(strsplit(filelist, "/",fixed=TRUE),`[`,1)))
  print(instances)
  all_files <- na.omit(unique(unlist(lapply(strsplit(filelist, "/",fixed=TRUE),`[`,2))))


  # choice of OpenSilex instance based on folder names in FilesToOpenSilex folder
  output$instance_ui <- shiny::renderUI({
    shinyWidgets::radioGroupButtons(inputId="instance",
                                    label="Choix instance OpenSilex",
                                    size="lg",
                                    individual=TRUE,
                                    choices=c("Pas de sélection"="",instances),
                                    status="danger",
                                    checkIcon = list(
                                      yes = icon("ok",
                                                 lib = "glyphicon")))
  })

  # output$instance_ui <- shiny::renderUI({
  #   shiny::radioButtons(inputId="instance",
  #                             label="Choix instance OpenSilex",
  #                             # size="lg",
  #                             choices=c("None selected" = "",instances),
  #                             inline=TRUE)
  # })




  observeEvent(input$instance,{
    req(input$instance)


    ## define prefix for downloading individual files
    pref_url <- "https://raw.github.com/chabrault/fto_files/master/"
    ## add selected instance
    pref_url <- paste0(pref_url,input$instance)

    metadataSO <- data.table::fread(paste0(pref_url, "/metadata.csv"),
                                    data.table=FALSE, check.names=FALSE)

    data_r6$ref_file <- data.table::fread(paste0(pref_url, "/reference_names.csv"),
                                          data.table=FALSE, check.names=FALSE)

    ## Table of variable list
    inputDFvar$variables <- data.table::fread(paste0(pref_url, "/variables.csv"),
                                              data.table=FALSE, check.names=FALSE)
    if(!"group" %in% colnames(inputDFvar$variables)){
      inputDFvar$variables$group <- "Autre"
    }

    output$tabVAR <- reactable::renderReactable(
      reactable::reactable(inputDFvar$variables[,!colnames(inputDFvar$variables) %in%
                                                  c("minValue","maxValue","lwrBound","uprBound")],
                           rownames=FALSE,
                           sortable=TRUE,
                           filterable=TRUE,
                           resizable=TRUE,
                           pagination=FALSE,
                           searchable=TRUE,
                           highlight=TRUE,
                           defaultColDef=reactable::colDef(align = "center",  filterable = TRUE),
                           height=800
      )
    )

    ## Table of validation of variable bounds
    inputDFvar$ValFile <- data.table::fread(paste0(pref_url, "/validationVariables.csv"),
                                            data.table=FALSE, check.names=FALSE)
    ## Table of correspondence of variable name
    inputDFvar$corresp_var <- data.table::fread(paste0(pref_url, "/corresp_variable_name.csv"),
                                                data.table=FALSE, check.names=FALSE)

    ## Table of germplasm
    germplasm <- data.table::fread(paste0(pref_url, "/germplasm.csv"),
                                   data.table=FALSE, check.names=FALSE)
    # remove whitespace at the end of name because removed in rhandsontable
    germplasm$name <- stringr::str_trim(germplasm$name, side="right")
    ##output$tabGerm <- DT::renderDataTable(germplasm)

    output$tabGerm <- reactable::renderReactable(
      reactable::reactable(germplasm,
                           rownames=FALSE,
                           sortable=TRUE,
                           filterable=TRUE,
                           resizable=TRUE,
                           pagination=FALSE,
                           searchable=TRUE,
                           highlight=TRUE,
                           defaultColDef=reactable::colDef(align = "center",  filterable = TRUE),
                           height=700
      )
    )

    ### Phenological stage table
    BBCH_table <- data.table::fread(paste0(pref_url, "/StadesBBCH_OntologiePPDO.tsv"),
                                    data.table=FALSE, check.names=FALSE)

    # Table of yeast
    yeast <- data.table::fread(paste0(pref_url, "/levures.tsv"),
                               data.table=FALSE, check.names=FALSE)

    datSO <- data.table::fread(paste0(pref_url, "/SO_all_expes.tsv"),
                               data.table=FALSE, check.names=FALSE)

    output$tabSO <- reactable::renderReactable(
      reactable::reactable(datSO,
                           rownames=FALSE,
                           sortable=TRUE,
                           groupBy = "name_expe",
                           filterable=TRUE,
                           resizable=TRUE,
                           pagination=FALSE,
                           searchable=TRUE,
                           highlight=TRUE,
                           defaultColDef=reactable::colDef(align = "center",  filterable = TRUE),
                           height=600
      )
    )

    data_r6$datSO_all <- datSO


    ## ---------- Import data ------------------------
    ### MODULE 1 mod_import_table ###
    datamods::set_i18n("fr")

    data_r6$import <- mod_import_table_server("import_table_1")
    #print(class(isolate(data_r6$import)))

    ##data_r6$import <- readxl::read_xlsx(path="examples/dispositifVaLoire 2017.xlsx",3)

    # --------- scientific object properties correspondence -----------
    ### MODULE 2 mod_corresp_SO ###
    mod_corresp_SO_server("corresp_SO_1",metadataSO=metadataSO,
                          germplasm=germplasm,data_r6=data_r6)

    ### MODULE 3 mod_edit_SO ###
    observeEvent(input$instance,{
      mod_edit_SO_server("edit_SO_1",metadataSO=metadataSO,
                         germplasm=germplasm,data_r6=data_r6)

      output$download_final <- downloadHandler(
        filename = paste0("correspSOFinal_",format(Sys.time(),"%Y-%m-%d_%H%M"),".csv"),
        content = function(fname){
          write.csv(req(data_r6$finalSO()), fname, row.names=FALSE, fileEncoding = "UTF-8")}
      )
      output$tab_SOfinal <- DT::renderDataTable({req(data_r6$finalSO())})
    })


    # ---------- Add data ---------------

    output$moreCols <- renderUI({
      selectInput("moreCols","Colonnes à afficher",
                  choices=colnames(req(data_r6$import())),
                  selected=NULL,
                  multiple=TRUE)
    })

    ### MODULE 4 mod_corresp_data ###
    res_mod <- reactiveVal()
    res_mod <- mod_corresp_data_server("corresp_data_1",inputDFvar=inputDFvar,
                                       data_r6=data_r6)
    data_r6$covarDFSO <- reactive(res_mod$covarDFSO())
    data_r6$df_colRender <- reactive(res_mod$df_colRender())
    data_r6$datSO <- reactive(res_mod$datSO())
    #observe(print(paste0("ncol covarDFSO server:",ncol(req(data_r6$covarDFSO())))))
    data_r6$moreCols <- reactive(res_mod$moreCols())

    ##output$tableTestRender <- renderTable(data_r6$df_colRender())


    ### Edit data ####
    ### MODULE 5 mod_edit_data ###
    res_edit <- reactiveVal()
    res_edit <- mod_edit_data_server("edit_data_1",data_r6=data_r6, BBCH_table=BBCH_table,
                                     inputDFvar=inputDFvar)
    data_r6$dat2 <- reactive(res_edit$Dat2())

    # transform table for OpenSilex with convertDatOp function
    ## remove columns added for printing
    dat_edit <- reactive({
      if(all(data_r6$moreCols() != "noMoreCols")){
        #colN <- colnames(data_r6$dat2())[!colnames(data_r6$dat2()) %in% data_r6$moreCols()]
        colN <- setdiff(colnames(data_r6$dat2()), data_r6$moreCols())
      } else {
        colN <- colnames(data_r6$dat2())
      }

      ## use convertDatOp function from fct_helpers.R
      dat_edit <- convertDatOp(editDF=data_r6$dat2()[,colN],
                               variables=inputDFvar$variables,
                               BBCH_table=BBCH_table,
                               modify_dates=input$modify_dates,
                               data_r6=data_r6)
      return(dat_edit)
    })

    #output$tableDataFinal <- DT::renderDataTable(dat_edit())
    ### new version with rhandsontable to highlight cell with out of bounds values
    output$tableDataFinal <- rhandsontable::renderRHandsontable({
      rhot <- rhandsontable::rhandsontable(dat_edit(),readOnly = TRUE,
                                           height=700,width=1300) %>%
        rhandsontable::hot_cols(renderer=colRender(df=verifDatBounds(dat=dat_edit(),
                                                                     valDF=inputDFvar$ValFile,
                                                                     varCol="uri")),
                                manualColumnResize=TRUE) %>%
        rhandsontable::hot_col(c(1:ncol(dat_edit()))[colSums(is.na(dat_edit()))==nrow(dat_edit())], width = 0.5)
      rhot
    })


    output$downloadTableDatFinal <- downloadHandler(
      filename = function() {
        paste0("corresp DATFinal",format(Sys.time(),"%Y-%m-%d_%H%M"),".csv")},
      content = function(fname){
        write.csv(dat_edit(),file= fname,row.names=FALSE, fileEncoding = "UTF-8")}
    )


    #
    #   ## ----------- Tab Referentiels ------------
    ## Print germplasm
    ## Print scientific objects

    # observe({
    #   #print(input$tabsetref)
    #   if (input$tabsetref == "Limites variables"){
    ## print("in tabset variable")
    ## -- MODULE edit_var_bounds --- ##
    mod_edit_var_bounds_server("edit_var_bounds_1",
                               inputDFvar=inputDFvar, data_r6=data_r6)
    # } else if (input$tabsetref == "Admin"){
    ## authentification (to update ref files) => in last tab
    mod_authentification_server("auth",instance=input$instance,
                                data_r6=data_r6)
    #}  else NULL
    #})



    ##  to access and updating referentiel files

    inputDF <- reactiveValues(Levures=yeast,StadesPheno=BBCH_table)

    observeEvent(input$refFile,{
      output$tabRef <- DT::renderDataTable({
        req(inputDF[[input$refFile]])
      })
    })

    output$downloadRefFile <- downloadHandler(
      filename = function() {
        paste0(input$refFile,format(Sys.time(),"%Y-%m-%d_%H%M"),".tsv")},
      content = function(fname){
        write.table(req(inputDF[[input$refFile]]), fname,
                    row.names=FALSE, sep="\t",quote=F,fileEncoding ="UTF-8")}
    )
  },ignoreInit=FALSE) # end observeEvent input$instance
}




