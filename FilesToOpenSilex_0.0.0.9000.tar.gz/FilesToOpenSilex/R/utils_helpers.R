#' helpers
#'
#' parse_status
#'
#' Parse an http response and display a message and a log
#' @param response_object object of class httr:response
#'
#' @return The same response_object passed in
#' @export
#' @importFrom logging loginfo logfine logwarn logerror
#' @author Guilhem Heinrich
parse_status <- function(response_object) {
  ch_status_code <- as.character(response_object$status_code)
  message <- status_code[[ch_status_code]]
  if (is.null(message)) {
    message <- "Unknown status code"
  }
  switch(substr(ch_status_code, 1, 1),
         "1" = {
           print("Informational Response.\n See logs for more information")
           logging::loginfo(paste(
             ch_status_code,
             message)
           )
         },
         "2" = {
           print("Query Success")
           logging::logfine(paste(
             ch_status_code,
             message)
           )
         },
         "3" = {
           print("Redirection event.\n See logs for more information")
           logging::logwarn(paste(
             ch_status_code,
             message)
           )
         },
         "4" = {
           print("Client error.\n See logs for more information")
           logging::logerror(paste(
             ch_status_code,
             message)
           )
         },
         "5" = {
           print("Server error.\n See logs for more information")
           logging::logerror(paste(
             ch_status_code,
             message)
           )
         }
  )
  return(response_object)
}



# Status code from https://en.wikipedia.org/wiki/List_of_HTTP_status_codes
status_code <- list(
  # 1xx Informational Response
  "100" = "Continue",
  "101" = "Switching Protocols",
  "102" = "Processing (WebDAV; RFC 2518)",
  "103" = "Early Hints (RFC 8297)",
  # 2xx Success
  "200" = "OK",
  "201" = "Created",
  "202" = "Accepted",
  "203" = "Non-Authoritative Information (since HTTP/1.1)",
  "204" = "No Content",
  "205" = "Reset Content",
  "206" = "Partial Content (RFC 7233)",
  "207" = "Multi-Status (WebDAV; RFC 4918)",
  "208" = "Already Reported (WebDAV; RFC 5842)",
  "209" = "IM Used (RFC 3229)",
  # 3xx Redirection
  "300" = "Multiple Choices",
  "301" = "Moved Permanently",
  "302" = " Found (Previously 'Moved temporarily')",
  "303" = "See Other (since HTTP/1.1)",
  "304" = "Not Modified (RFC 7232)",
  "305" = "Use Proxy (since HTTP/1.1)",
  "306" = "Switch Proxy",
  "307" = "Temporary Redirect (since HTTP/1.1)",
  "308" = "Permanent Redirect (RFC 7538)",
  # 4xx Client error
  "400" = "Bad Request",
  "401" = "Unauthorized (RFC 7235)",
  "402" = "Payment Required",
  "403" = "Forbidden",
  "404" = "Not Found",
  "405" = "Method Not Allowed",
  "406" = "Not Acceptable",
  "407" = "Proxy Authentication Required (RFC 7235)",
  "408" = "Request Timeout",
  "409" = "Conflict",
  "410" = "Gone",
  "411" = "Length Required",
  "412" = "Precondition Failed (RFC 7232)",
  "413" = "Payload Too Large (RFC 7231)",
  "414" = "URI Too Long (RFC 7231)",
  "415" = "Unsupported Media Type (RFC 7231)",
  "416" = "Range Not Satisfiable (RFC 7233)",
  "417" = "Expectation Failed",
  "418" = "I'm a teapot (RFC 2324, RFC 7168)",
  "421" = "Misdirected Request (RFC 7540)",
  "422" = "Unprocessable Entity (WebDAV; RFC 4918)",
  "423" = "Locked (WebDAV; RFC 4918)",
  "424" = "Failed Dependency (WebDAV; RFC 4918)",
  "425" = "Too Early (RFC 8470)",
  "426" = "Upgrade Required",
  "428" = "Precondition Required (RFC 6585)",
  "429" = "Too Many Requests (RFC 6585)",
  "431" = "Request Header Fields Too Large (RFC 6585)",
  "451" = "Unavailable For Legal Reasons (RFC 7725)",
  # 5xx Server error
  "500" = "Internal Server Error",
  "501" = "Not Implemented",
  "502" = "Bad Gateway",
  "503" = "Service Unavailable",
  "504" = "Gateway Timeout",
  "505" = "HTTP Version Not Supported",
  "506" = "Variant Also Negotiates (RFC 2295)",
  "507" = "Insufficient Storage (WebDAV; RFC 4918)",
  "508" = "Loop Detected (WebDAV; RFC 5842)",
  "510" = "Not Extended (RFC 2774)",
  "511" = "Network Authentication Required (RFC 6585)",
  # Nginx
  "444" = "[nginx] No Response",
  "494" = "[nginx] Request header too large",
  "495" = "[nginx] SSL Certificate Error",
  "496" = "[nginx] SSL Certificate Required",
  "497" = "[nginx] HTTP Request Sent to HTTPS Port",
  "499" = "[nginx] Client Closed Request"
)

#' Get Token
#'
#' Function use to get the token for a user
#' @param host url of the hosting opensilex service
#' @param user opensilex user
#' @param password opensilex user's password
#'
#' @return A string token, used by every subsequent call
#' @export
#' @importFrom httr POST content add_headers
#' @importFrom jsonlite fromJSON
#' @author Guilhem Heinrich
get_token <- function(host, user = "guest@opensilex.org", password = "guest") {
  call0 <- paste0(host, "/security/authenticate")
  post_authenticate <- parse_status(
    httr::POST(
      call0,
      body = paste0('{
          "identifier": "', user, '",
          "password": "', password, '"
          }'
      ),
      httr::add_headers(
        `Content-Type` = "application/json",
        Accept = "application/json"
      )
    )
  )
  post_authenticate_text <- httr::content(post_authenticate, "text")
  post_authenticate_json <- jsonlite::fromJSON(
    post_authenticate_text,
    flatten = TRUE
  )
  token <- post_authenticate_json$result$token
  return(token)
}
