#' update_var UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
mod_update_var_ui <- function(id){
  ns <- NS(id)
  tagList(
    shiny::verbatimTextOutput(ns("maj_variable")),
    downloadButton(ns("DWNLD_VAR_UP"),"Télécharger le fichier"),
    br()
  )
}

#' update_var Server Functions
#'
#' @noRd
mod_update_var_server <- function(id, host, user, password,
                                  data_r6, instance){
  moduleServer( id, function(input, output, session){
    ns <- session$ns
    cat("Updating variable list...")
    #print(host)
    token <- get_token(host=host, user=user,password=password)
    # print(paste("class token:",class(token)))
    # print(token)
    #### download the list of variables
    ## TODO: understand why it is not working with VitisExplorer => reported bug
    startTime <- Sys.time()

    ### not working for VitisExplorer instance
    if(data_r6$ref_file$prefix_SO_URI[data_r6$ref_file$Name == "Id2"] == "Sinfonia"){
      VAR = httr::GET(paste0(host,"/core/variables/details"),
                      query = list(page_size = 10000),
                      httr::content_type_json(),encode ="raw",
                      httr::add_headers(Authorization=token))
      dfVAR = jsonlite::fromJSON(rawToChar(VAR$content))$result
      dfVAR <- jsonlite::flatten(as.data.frame(dfVAR))
      dfVAR<- tidyr::unnest(dfVAR, colnames(dfVAR)[sapply(dfVAR, class)=="list"],
                            keep_empty = TRUE)

      ## other way is faster but not working for Sinfonia (gateway time-out)
    } else {
      print("not Sinfonia")

      VAR = httr::GET(paste0(host,"/core/variables"),
                      query = list(page_size = 10000),
                      httr::content_type_json(),encode ="raw",
                      httr::add_headers(Authorization=token))
      VAR = jsonlite::fromJSON(rawToChar(VAR$content))$result
      VAR <- jsonlite::flatten(as.data.frame(VAR))
      VAR<- tidyr::unnest(VAR, colnames(VAR)[sapply(VAR, class)=="list"],
                          keep_empty = TRUE)

      #dim(VAR)
      varsURIs <-paste(VAR$uri,collapse='","')

      url <- paste0(host,"/core/variables/export_details_by_uris")
      post_result <-
        httr::POST(
          url,
          body = paste0('{"uris": ["', varsURIs, '"]}'),
          httr::add_headers(
            Authorization = token,
            `Content-Type` = "application/json"
          )
        )
      ##post_result
      dfVAR <- read.csv(
        text = httr::content(post_result, "text"),
        #skip = 1,
        #col.names =  header_lines[1,],
        row.names = NULL,
        check.names = FALSE
      )
      dfVAR <- dplyr::rename(dfVAR,
                             alternative_name=alternativeName,
                             datatype=dataType)

    } # end else

    ## look for variable groups
    body <-  paste0('{"variableUri": ["', paste(dfVAR$uri,collapse='","'), '"]
                page_size=100}')

    GROUPVAR = httr::GET(url=paste0(host,"/core/variables_group"),
                         body =body,#paste0('{"uri": [',dfVAR$uri[1],']}'),
                         httr::add_headers(
                           Authorization = token,
                           `Content-Type` = "application/json"
                         )
    )
    dfGROUPVAR = jsonlite::fromJSON(rawToChar(GROUPVAR$content))$result
    dfGROUPVAR<-jsonlite::flatten(dfGROUPVAR)
    dfGROUPVAR<- tidyr::unnest(dfGROUPVAR, colnames(dfGROUPVAR)[sapply(dfGROUPVAR, class)=="list"],
                               keep_empty = TRUE, names_repair = "universal")

    colnames(dfGROUPVAR)[1:5] <- c("URIgroup","group","descriptionGroup","uri","name")

    ## merge var details and group
    VARfinal <- merge(dfVAR,dfGROUPVAR,all.x=TRUE)

    ## NB: exact_match not found with POST request
    VARfinal <- VARfinal[,colnames(VARfinal) %in% c("uri","name","description","alternative_name",
                                                    "datatype","URIgroup","group","exact_match")]


    ## Local download for user
    output$DWNLD_VAR_UP <- downloadHandler(
      filename = "variables.csv",content = function(fname){
        write.csv(VARfinal,fname, row.names=FALSE, fileEncoding="UTF-8")
      }
    )
    executionTime <- Sys.time()-startTime
    # write(paste(Sys.time(),round(executionTime,0),sep=";"),
    #       file="OpenSilexFiles/logVar.txt",append=TRUE)
    output$maj_variable <-  shiny::renderPrint({
      cat(paste0("Requête terminée en ",round(executionTime,0)," secondes"))
    })

  }) # module Server
}

## To be copied in the UI
# mod_update_var_ui("update_var_1")

## To be copied in the server
# mod_update_var_server("update_var_1")
