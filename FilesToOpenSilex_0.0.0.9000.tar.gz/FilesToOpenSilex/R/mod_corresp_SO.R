#' corresp_SO UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
mod_corresp_SO_ui <- function(id){
  ns <- NS(id)
  tagList(
    fluidPage(
      bs4Dash::box(width=10,
                   #height="150px",
                   title="Choix type objet scientifique",
                   uiOutput(ns("selSOtype")),

                   status="primary"
      ),
      #br(),

      fluidRow(
        bs4Dash::box(width=8,
                     height="600px",
                     title="Tableau correspondance",
                     closable = FALSE,
                     maximizable = TRUE,
                     style = "overflow-y: scroll",
                     status="danger",
                     h5("Editer la correspondance entre les propriétés du type d'objet scientifique choisi et les colonnes du tableau"),
                     br(),
                     conditionalPanel("input.selSOtype!=''",
                                      rhandsontable::rHandsontableOutput(ns("edit_rht_os1"))),

                    # rhandsontable::rHandsontableOutput(ns("edit_rht_os1")),
                     br(),
                     downloadButton(ns("DWNLD_SO1"),"Télécharger le fichier")
        ),

        bs4Dash::box(width=4, height="500px",
                     title=" Aide remplissage",
                     #closable = TRUE,
                     maximizable = TRUE,
                     collapsed=TRUE,
                     style = "overflow-y: scroll",
                     status="info",
                     icon=icon("question"),
                     p("Remplir la colonne ",
                       em("'Correspondance'"),
                       "Avec les noms de colonne du tableau (voir liste déroulante)"),
                     p("Seul le nom est obligatoire, les autres propriétés sont optionnelles"),
                     p("Les propriétés 'uri' et 'type' seront remplies automatiquement"),
                     p("Si nécessaire, utiliser une formule pour générer le nom comme ",
                       code('paste0("prefix_",PU)'),
                       " si la colonne PU permet d'identifier uniquement l'objet scientifique"),

                     br(),
                     p("Certaines propriétés doivent contenir des URI, c'est le cas de l'installation technique",
                       "de l'objet parent (par exemple la parcelle dans laquelle est présente la placette)",
                       "ou bien encore le niveau de facteur."),
                     p("Ces URI doivent être récupérées sur le site internet d'OpenSilex"),
                     br(),
                     #h5("Noms avec accent ou espace"),
                     p("S'il y a des accents dans les noms, il faut les entourer avec un guillemet spécial"),
                     p("Vous pouvez l'obtenir en tapant ", code("AltGr + 7 + Espace")),

                     br(),
                     p("La colonne ",em("Edition")," permet de sélectionner",
                       "les colonnes qui seront éditées par la suite")


        )
      ),

      br(),

      bs4Dash::box(width=12, height="500px",
                   title="Table vérification",
                   status="pink",
                   h5("Vérification du bon remplissage des colonnes et de l'unicité du nom de l'objet scientifique (noms en vert)"),
                   DT::dataTableOutput(ns("DTtest")),
                   style = "height:450px; width:100%; overflow-y: scroll;overflow-x: scroll;"
      )
    )
  )
}

#' corresp_SO Server Functions
#' #' This module creates the correspondence file to be edited by hand, using rhandsontable and
#' create the dataframe with replaced column names
#'
#' @param id shiny module id
#' @param germplasm  data frame of germplasm in OpenSilex
#' @param metadataSO data frame with Propriete associated with type of scientific objects
#' @param data_r6 R6 object, containing object "import" with user data frame imported
#'
#'
#' @noRd
mod_corresp_SO_server <- function(id,germplasm,metadataSO,data_r6){
  moduleServer( id, function(input, output, session){
    ns <- session$ns

    ## colnames of ref file: English SO names
    ch <- colnames(data_r6$ref_file)[4:ncol(data_r6$ref_file)]
    ## here: French SO names
    names(ch) <- data_r6$ref_file[2,4:ncol(data_r6$ref_file)]


    output$selSOtype <- renderUI({

      shinyWidgets::radioGroupButtons(
        inputId = ns("selSOtype"),
        label = "Type objet scientifique",
        choices=ch,
        selected="",
       # selected="Sub-plot",
       # individual=TRUE,
        status = "success"
      )

    })
    #observe(print(input$selSOtype))

    corrDF <- reactiveVal(NULL)
    res_fun <- reactiveVal(NULL)
    ### select type of metadata according to SO type
    observeEvent(input$selSOtype,{
      corrDF <- reactive(data.frame(Propriete=metadataSO$prop_read[metadataSO[[req(input$selSOtype)]]],
                                    Correspondance = NA,
                                    Edition = TRUE)) ## correspondence table empty)

      ## TODO: automatically add type of scientific object in corrDF
      #observe(print(colnames(corrDF())))

      # use rhandsontable package
      output$edit_rht_os1 <- rhandsontable::renderRHandsontable(
        rhandsontable::rhandsontable(req(corrDF()), width=800) %>%
          rhandsontable::hot_col(col="Propriete", readOnly=TRUE) %>%
          rhandsontable::hot_table(overflow="visible",highlightCol=TRUE,
                                   highlightRow=TRUE,rowHeaderWidth=0) %>%
          rhandsontable::hot_col(col="Correspondance",
                                 type="dropdown",
                                 source=c("",
                                          # example name for VitisExplorer
                                          'paste0("prefix_",PU)',
                                          # example name for Sinfonia
                                          'paste0("B",bloc,"R",Rang,"s",`Première souche`)',
                                          # raw column names
                                          colnames(req(data_r6$import()))),
                                 halign="htCenter",
                                 allowInvalid=TRUE) %>%
          rhandsontable::hot_col(col="Edition",type="checkbox") %>%
          rhandsontable::hot_cols(halign="htCenter",valign="htMiddle",
                                  manualColumnResize=TRUE,colWidths=c(175,220,75))
      )

      ## Local download for user
      output$DWNLD_SO1 <- downloadHandler(
        filename = paste0("corresp_SO1",format(Sys.time(),"%Y-%m-%d_%H%M"),".csv"),
        content = function(fname){
          write.csv(req(rhandsontable::hot_to_r(input$edit_rht_os1)),fname,
                    row.names=FALSE, fileEncoding = "UTF-8")
        }
      )

      ## Create data frame to edit
      observeEvent(c(req(corrDF())),{
        ### Use editDFCorresp function, from fct_helpers.R
        res_fun <<- reactive({
          editDFCorresp(userDF=req(data_r6$import()),
                        metaNames= metadataSO$prop_read[metadataSO[[req(input$selSOtype)]]],
                        corresp=req(rhandsontable::hot_to_r(input$edit_rht_os1)),
                        germplasm=germplasm)
        })
      }, ignoreInit=FALSE)

      observeEvent(res_fun(),{
        output$DTtest <- DT::renderDataTable({
          formattable::as.datatable(
            formattable::formattable(req(res_fun()$df),
                                     list(Nom=formattable::formatter(
                                       "span",style=x ~style(color=ifelse(
                                         duplicated(x)|duplicated(x,fromLast=TRUE),"red","green"))))
            )
          )
        })
      }, ignoreInit=FALSE)

      data_r6$edit_SO_1 <- reactive(req(res_fun()$df))
      data_r6$colRender_SO_1 <- reactive(req(res_fun()$colRender))
      data_r6$SOtype <- reactive(req(input$selSOtype))
      ##observe(print(req(data_r6$colRender_SO_1())))

    }, ignoreInit=TRUE)# observeEvent selSOtype

    return(data_r6)

  })
}

## To be copied in the UI
# mod_corresp_SO_ui("corresp_SO_1")

## To be copied in the server
# mod_corresp_SO_server("corresp_SO_1")
